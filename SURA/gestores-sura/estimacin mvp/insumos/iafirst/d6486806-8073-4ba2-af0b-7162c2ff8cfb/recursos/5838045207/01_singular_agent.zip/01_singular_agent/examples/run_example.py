from pathlib import Path
from src.singular_agent.config import load_config
from src.singular_agent.models import AgentRequest
from src.singular_agent.orchestrator import SingularAgentOrchestrator

base = Path(__file__).resolve().parents[1]
config = load_config(base)
orchestrator = SingularAgentOrchestrator(config['agent_manifest'], config['prompts'])
response = orchestrator.run(AgentRequest(user_id='demo.user', input_text='Resume las condiciones de una póliza usando conocimiento autorizado'))
print(response.status)
print(response.answer)
print('traces:', len(response.trace))
