from planner_executor_reviewer.application.ports.prompt_port import PromptPort, RenderedPrompt
from planner_executor_reviewer.domain.models import TraceContext


class FakePromptManagementAdapter(PromptPort):
    async def get_prompt(
        self,
        prompt_id: str,
        version_policy: str,
        environment: str,
        variables: dict,
        trace_context: TraceContext,
    ) -> RenderedPrompt:
        return RenderedPrompt(
            prompt_id=prompt_id,
            version="test",
            content="This is a fake prompt for tests only. Input: {input}",
            metadata={"fake": True},
        )
