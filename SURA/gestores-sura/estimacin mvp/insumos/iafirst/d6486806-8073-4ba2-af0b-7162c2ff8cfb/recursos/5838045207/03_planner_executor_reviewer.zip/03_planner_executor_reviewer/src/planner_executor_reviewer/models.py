from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from uuid import uuid4
from datetime import datetime, timezone


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class DecisionTrace:
    step: str
    decision: str
    reason: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=utc_now)


@dataclass
class AgentRequest:
    user_id: str
    input_text: str
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    correlation_id: str = field(default_factory=lambda: str(uuid4()))


@dataclass
class AgentResponse:
    correlation_id: str
    answer: str
    status: str
    trace: List[DecisionTrace]
    artifacts: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ToolRequest:
    tool_name: str
    payload: Dict[str, Any]
    correlation_id: str
    user_id: str


@dataclass
class ToolResponse:
    tool_name: str
    ok: bool
    result: Dict[str, Any]
    error: Optional[str] = None


@dataclass
class EventEnvelope:
    event_type: str
    payload: Dict[str, Any]
    correlation_id: str
    producer: str
    occurred_at: str = field(default_factory=utc_now)
