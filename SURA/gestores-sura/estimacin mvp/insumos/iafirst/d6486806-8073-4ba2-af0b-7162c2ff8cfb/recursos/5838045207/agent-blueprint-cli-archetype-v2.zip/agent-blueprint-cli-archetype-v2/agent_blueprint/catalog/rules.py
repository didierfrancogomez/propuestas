from agent_blueprint.models import AgentDefinition


class CompositionError(ValueError):
    pass


ALWAYS_REQUIRED = {
    "base",
    "prompt-management",
    "observability-otel",
    "policy-engine",
}


def apply_rules(components: set[str], features: dict) -> set[str]:
    components |= ALWAYS_REQUIRED

    if features.get("tools") == "mcp":
        components |= {"tools-mcp", "policy-engine", "observability-otel"}

    if features.get("inbound") == "event":
        components |= {"inbound-event", "event-broker", "idempotency"}

    if features.get("inbound") == "http":
        components |= {"inbound-http"}

    if features.get("a2a") is True:
        components |= {"a2a"}

    if features.get("internal_mcp_server") is True:
        components |= {"internal-mcp-server"}

    if features.get("memory") == "episodic":
        components |= {"memory-episodic"}

    if features.get("reviewer") is True:
        components |= {"evaluation-service"}

    return components


def validate_definition(definition: AgentDefinition) -> None:
    components = set(definition.components)

    if "prompt-management" not in components:
        raise CompositionError("Prompt Management is mandatory for all generated agents")

    if "tools-mcp" in components and "policy-engine" not in components:
        raise CompositionError("MCP tools require policy-engine")

    if "inbound-event" in components:
        missing = {"event-broker", "idempotency"} - components
        if missing:
            raise CompositionError(f"Event-driven profile requires: {sorted(missing)}")

    if "a2a" in components and definition.features.get("a2a") is not True:
        raise CompositionError("A2A component requires features.a2a=true")
