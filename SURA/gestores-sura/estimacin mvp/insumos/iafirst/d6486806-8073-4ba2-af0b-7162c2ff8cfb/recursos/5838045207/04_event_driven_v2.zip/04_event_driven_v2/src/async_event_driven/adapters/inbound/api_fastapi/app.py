from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Header, Request
from pydantic import BaseModel

from async_event_driven.domain.models import AgentRequest, TraceContext, UserContext
from async_event_driven.application.use_cases.orchestrate_request import OrchestrateRequestUseCase
from async_event_driven.bootstrap.dependency_container import DependencyContainer

from async_event_driven.adapters.inbound.a2a.routes import router as a2a_router



@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.container = DependencyContainer()
    yield


app = FastAPI(title="async-event-driven", lifespan=lifespan)

app.include_router(a2a_router)



class InvokeRequest(BaseModel):
    input: str
    session_id: str


def _split_header_values(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def get_container(request: Request) -> DependencyContainer:
    return request.app.state.container


def get_orchestrate_use_case(container: DependencyContainer = Depends(get_container)) -> OrchestrateRequestUseCase:
    return container.orchestrate_request_use_case


def get_user_context(
    x_user_id: str | None = Header(default=None),
    x_user_roles: str | None = Header(default=None),
    x_user_scopes: str | None = Header(default=None),
    x_tenant_id: str | None = Header(default=None),
) -> UserContext:
    return UserContext(
        user_id=x_user_id,
        roles=_split_header_values(x_user_roles),
        scopes=_split_header_values(x_user_scopes),
        tenant_id=x_tenant_id,
        auth_source="http_headers" if x_user_id or x_user_roles or x_user_scopes else None,
    )


@app.get("/health")
def health():
    return {"status": "ok", "agent": "async-event-driven"}


@app.post("/invoke")
async def invoke(
    payload: InvokeRequest,
    x_correlation_id: str | None = Header(default=None),
    user_context: UserContext = Depends(get_user_context),
    use_case: OrchestrateRequestUseCase = Depends(get_orchestrate_use_case),
):
    trace = TraceContext(correlation_id=x_correlation_id or payload.session_id)
    request = AgentRequest(
        input=payload.input,
        session_id=payload.session_id,
        user_context=user_context,
        trace_context=trace,
    )
    response = await use_case.execute(request)
    return response.model_dump()
