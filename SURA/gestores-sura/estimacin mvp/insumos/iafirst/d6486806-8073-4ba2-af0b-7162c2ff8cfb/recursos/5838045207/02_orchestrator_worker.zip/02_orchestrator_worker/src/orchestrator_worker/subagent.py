from __future__ import annotations

from typing import Any, Dict, List
from .models import AgentRequest, DecisionTrace, ToolRequest
from .policy import PolicyEngine
from .mcp_client import MockMCPClient
from .llm_client import MockLLMGateway
from .prompts import PromptRegistry


class SubAgent:
    def __init__(self, name: str, role: str, tools: List[str], policy: PolicyEngine, prompts: PromptRegistry):
        self.name = name
        self.role = role
        self.tools = tools
        self.policy = policy
        self.prompts = prompts
        self.mcp = MockMCPClient()
        self.llm = MockLLMGateway()

    def execute(self, request: AgentRequest, task: Dict[str, Any]) -> Dict[str, Any]:
        trace = [DecisionTrace(
            step=f'subagent.{self.name}.start',
            decision='execute_task',
            reason=f'Subagente {self.role} ejecuta una tarea acotada',
            metadata={'task': task},
        )]
        tool_results: Dict[str, Any] = {}
        for tool in self.tools:
            self.policy.validate_tool(tool)
            response = self.mcp.call(ToolRequest(tool_name=tool, payload={'query': task.get('description', request.input_text)}, correlation_id=request.correlation_id, user_id=request.user_id))
            tool_results[tool] = response.result if response.ok else {'error': response.error}
            trace.append(DecisionTrace(step=f'subagent.{self.name}.tool', decision=tool, reason='Tool autorizada y ejecutada', metadata=tool_results[tool]))
        prompt = self.prompts.render('worker_response', role=self.role, task=task.get('description', ''), evidence=str(tool_results))
        output = self.llm.complete(prompt, metadata={'intent': self.role})
        trace.append(DecisionTrace(step=f'subagent.{self.name}.finish', decision='return_structured_result', reason='Resultado estructurado devuelto al orquestador'))
        return {'name': self.name, 'role': self.role, 'output': output, 'tool_results': tool_results, 'trace': trace}
