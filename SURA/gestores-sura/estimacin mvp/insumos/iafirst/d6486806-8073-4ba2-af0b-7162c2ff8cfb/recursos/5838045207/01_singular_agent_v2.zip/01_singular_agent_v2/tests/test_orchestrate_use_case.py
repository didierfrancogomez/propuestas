import asyncio

from single_agent_conversational.application.use_cases.orchestrate_request import OrchestrateRequestUseCase
from single_agent_conversational.domain.models import AgentRequest, TraceContext, UserContext
from fakes.fake_orchestration import FakeOrchestration
from fakes.fake_telemetry import FakeTelemetry


def test_orchestrate_request_uses_ports():
    response, telemetry = asyncio.run(_execute_use_case())

    assert response.answer == "fake response for hello"
    assert ("agent.request.received", {"session_id": "session-1"}) in telemetry.events
    assert ("agent.request.completed", {"session_id": "session-1"}) in telemetry.events


async def _execute_use_case():
    telemetry = FakeTelemetry()
    use_case = OrchestrateRequestUseCase(
        telemetry=telemetry,
        orchestration=FakeOrchestration(),
    )
    request = AgentRequest(
        input="hello",
        session_id="session-1",
        user_context=UserContext(user_id="user-1", scopes=["agents.invoke"]),
        trace_context=TraceContext(correlation_id="corr-1"),
    )

    response = await use_case.execute(request)
    return response, telemetry
