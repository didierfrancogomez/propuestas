from pathlib import Path
from uuid import uuid4
from src.event_driven.config import load_config
from src.event_driven.models import EventEnvelope
from src.event_driven.event_bus import InMemoryEventBus
from src.event_driven.orchestrator import EventDrivenAgent


def test_event_driven_consumes_and_publishes_result():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    bus = InMemoryEventBus()
    agent = EventDrivenAgent(config['agent_manifest'], config['prompts'], bus=bus)
    bus.enqueue(EventEnvelope(event_type='business.document.received', payload={'user_id': 'system', 'text': 'Documento recibido'}, correlation_id=str(uuid4()), producer='test'))
    response = agent.poll_once()
    assert response.status == 'ok'
    assert len(bus.outbox) == 1
    assert bus.outbox[0].event_type == 'agent.result.created'
    assert any(t.step == 'event.published' for t in response.trace)
