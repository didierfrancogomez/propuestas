from pathlib import Path
from uuid import uuid4
from src.event_driven.config import load_config
from src.event_driven.models import EventEnvelope
from src.event_driven.event_bus import InMemoryEventBus
from src.event_driven.orchestrator import EventDrivenAgent

base = Path(__file__).resolve().parents[1]
config = load_config(base)
bus = InMemoryEventBus()
agent = EventDrivenAgent(config['agent_manifest'], config['prompts'], bus=bus)
bus.enqueue(EventEnvelope(event_type='business.document.received', payload={'user_id': 'system', 'text': 'Documento recibido para análisis'}, correlation_id=str(uuid4()), producer='demo'))
response = agent.poll_once()
print(response.status)
print(response.answer)
print('outbox:', [e.event_type for e in bus.outbox])
