from dataclasses import dataclass

from single_agent_conversational.application.ports.llm_port import LLMPort
from single_agent_conversational.application.ports.policy_port import PolicyPort
from single_agent_conversational.application.ports.telemetry_port import TelemetryPort

from single_agent_conversational.application.prompts.prompt_runtime import PromptRuntime


from single_agent_conversational.application.ports.tool_port import ToolPort





@dataclass(frozen=True)
class GraphDependencies:
    """Ports available to LangGraph node factories.

    Keep concrete adapters out of graph nodes. The dependency container builds this
    object once and passes it to build_graph().
    """

    telemetry: TelemetryPort
    policy_engine: PolicyPort
    llm: LLMPort | None = None

    prompt_runtime: PromptRuntime | None = None


    tools: ToolPort | None = None



