from single_agent_conversational.application.use_cases.orchestrate_request import OrchestrateRequestUseCase
from single_agent_conversational.bootstrap.settings import Settings
from single_agent_conversational.adapters.outbound.langgraph.dependencies import GraphDependencies
from single_agent_conversational.adapters.outbound.langgraph.runner import LangGraphOrchestrationRunner
from single_agent_conversational.adapters.outbound.policy_engine.adapter import PolicyEngineAdapter
from single_agent_conversational.adapters.outbound.telemetry_otel.adapter import OpenTelemetryAdapter

from single_agent_conversational.adapters.outbound.llm_gateway.adapter import LLMGatewayAdapter



from single_agent_conversational.adapters.outbound.prompt_management.adapter import PromptManagementAdapter
from single_agent_conversational.adapters.outbound.prompt_management.client import PromptManagementClient
from single_agent_conversational.application.prompts.prompt_runtime import PromptRuntime


from single_agent_conversational.adapters.outbound.mcp_client.adapter import MCPClientAdapter



from single_agent_conversational.adapters.outbound.langgraph.graphs.single_agent_graph import build_graph



class DependencyContainer:
    """Composition root for adapters, ports and use cases."""

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or Settings()
        self._validate_required_settings()
        self.telemetry = OpenTelemetryAdapter()
        self.policy_engine = PolicyEngineAdapter()

        self.llm = (
            LLMGatewayAdapter(self.settings.llm_gateway_url)
            if self.settings.llm_gateway_url
            else None
        )



        self.prompt_management = self._build_prompt_management()
        self.prompt_runtime = (
            PromptRuntime(self.prompt_management, environment=self.settings.environment)
            if self.prompt_management is not None
            else None
        )


        self.tools = (
            MCPClientAdapter(self.settings.mcp_gateway_url)
            if self.settings.mcp_gateway_url
            else None
        )


        self.graph_dependencies = GraphDependencies(
            telemetry=self.telemetry,
            policy_engine=self.policy_engine,

            llm=self.llm,


            prompt_runtime=self.prompt_runtime,


            tools=self.tools,



        )
        self.graph = build_graph(self.graph_dependencies)
        self.orchestration = LangGraphOrchestrationRunner(self.graph)
        self.orchestrate_request_use_case = OrchestrateRequestUseCase(
            telemetry=self.telemetry,
            orchestration=self.orchestration,
        )


    def _build_prompt_management(self) -> PromptManagementAdapter | None:
        client = PromptManagementClient(self.settings.prompt_management_url)
        return PromptManagementAdapter(client)


    def _validate_required_settings(self) -> None:

        if not self.settings.prompt_management_url:
            raise ValueError("AGENT_PROMPT_MANAGEMENT_URL is required because Prompt Management is mandatory")


        if not self.settings.llm_gateway_url:
            raise ValueError("AGENT_LLM_GATEWAY_URL is required for the LLM Gateway adapter")


        if not self.settings.mcp_gateway_url:
            raise ValueError("AGENT_MCP_GATEWAY_URL is required when MCP tools are enabled")

