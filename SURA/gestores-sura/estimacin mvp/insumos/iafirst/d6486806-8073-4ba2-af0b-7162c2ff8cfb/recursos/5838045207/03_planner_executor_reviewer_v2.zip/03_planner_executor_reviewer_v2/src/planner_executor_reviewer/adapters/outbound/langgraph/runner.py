from inspect import isawaitable
from typing import Any

from planner_executor_reviewer.application.ports.orchestration_port import OrchestrationPort
from planner_executor_reviewer.domain.models import AgentRequest, AgentResponse


class LangGraphOrchestrationRunner(OrchestrationPort):
    def __init__(self, graph: Any):
        self.graph = graph

    async def run(self, request: AgentRequest) -> AgentResponse:
        state = {
            "input": request.input,
            "session_id": request.session_id,
            "user_context": request.user_context.model_dump(),
            "trace_context": request.trace_context.model_dump(),
        }

        result = await self._invoke_graph(state)
        answer = result.get("final_response") or "Agent runtime generated. Implement domain response logic here."
        return AgentResponse(
            answer=answer,
            session_id=request.session_id,
            trace_context=request.trace_context,
            metadata={
                "plan": result.get("plan"),
                "worker_results": result.get("worker_results", []),
                "tool_calls": result.get("tool_calls", []),
                "errors": result.get("errors", []),
            },
        )

    async def _invoke_graph(self, state: dict[str, Any]) -> dict[str, Any]:
        if hasattr(self.graph, "ainvoke"):
            return await self.graph.ainvoke(state)
        if hasattr(self.graph, "invoke"):
            return self.graph.invoke(state)
        if callable(self.graph):
            result = self.graph(state)
            if isawaitable(result):
                return await result
            return result
        raise TypeError("Configured graph must expose ainvoke, invoke, or be callable")
