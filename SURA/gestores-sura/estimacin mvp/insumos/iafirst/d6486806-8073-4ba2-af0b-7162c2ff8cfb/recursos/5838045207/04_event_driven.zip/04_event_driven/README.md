# Plantilla 04 - Event-Driven Agent

## Propósito

Referencia para agentes que se activan por eventos y publican resultados desacoplados para consumidores downstream.

## Cuándo usar

- Procesos asincrónicos.
- Eventos de negocio o técnicos.
- Procesamiento de documentos, cambios de estado, alertas o radicaciones.
- Necesidad de retries, DLQ e idempotencia en evolución productiva.

## Flujo de ejecución

```mermaid
sequenceDiagram
  participant S as Sistema productor
  participant B as Broker/Event Bus
  participant E as Event Listener
  participant O as Event-Driven Agent
  participant T as MCP/Tools
  participant C as Consumidor downstream
  S->>B: EventEnvelope
  E->>B: consume event
  E->>O: handle_event
  O->>T: tool autorizada
  O->>B: agent.result.created
  B-->>C: resultado disponible
```

## Componentes

| Componente | Archivo | Responsabilidad |
|---|---|---|
| Event Bus mock | `event_bus.py` | Simula broker in-memory. |
| Event Listener | `poll_once()` | Consume un evento. |
| Orquestador | `handle_event()` | Procesa evento y publica resultado. |
| Protocolos | `models.py` | Define EventEnvelope. |
| Policy | `policy.py` | Valida entrada y tools. |

## Ejecutar

```bash
python examples/run_example.py
pytest -q
```

## Criterios de aceptación

- El agente consume un `EventEnvelope`.
- El resultado se publica como `agent.result.created`.
- El `correlation_id` se conserva extremo a extremo.
- La tool ejecutada está autorizada.
- El flujo puede ejecutarse sin sistemas externos reales.

## Evolución a implementación real

- Reemplazar `InMemoryEventBus` por broker aprobado.
- Incorporar DLQ, retries, backoff e idempotencia.
- Definir contratos AsyncAPI.
- Monitorear lag, errores, duplicados y tiempos de procesamiento.
