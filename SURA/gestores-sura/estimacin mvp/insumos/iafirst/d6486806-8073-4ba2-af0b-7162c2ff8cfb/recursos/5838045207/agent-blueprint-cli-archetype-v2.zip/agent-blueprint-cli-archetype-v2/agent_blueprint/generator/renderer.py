from importlib import resources
from pathlib import Path
import shutil

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from agent_blueprint.models import AgentDefinition


class ProjectRenderer:
    def __init__(self):
        self.templates_root = Path(str(resources.files("agent_blueprint") / "templates"))
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_root)),
            undefined=StrictUndefined,
            keep_trailing_newline=True,
        )

    def render(self, definition: AgentDefinition) -> None:
        output = definition.output
        if output.exists() and any(output.iterdir()):
            raise FileExistsError(f"Output directory already exists and is not empty: {output}")
        output.mkdir(parents=True, exist_ok=True)

        context = definition.model_dump(mode="json")
        context["package_name"] = definition.package_name

        for component in definition.components:
            component_dir = self.templates_root / "components" / component
            if not component_dir.exists():
                raise FileNotFoundError(f"Unknown component template: {component}")
            self._render_component(component_dir, output, context)

    def _render_component(self, component_dir: Path, output: Path, context: dict) -> None:
        for item in component_dir.rglob("*"):
            if item.is_dir():
                continue
            rel = item.relative_to(component_dir)
            rendered_rel = self.env.from_string(rel.as_posix()).render(**context)
            if rendered_rel.endswith(".j2"):
                rendered_rel = rendered_rel[:-3]
            dest = output / rendered_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            template_name = item.relative_to(self.templates_root).as_posix()
            if item.name.endswith(".j2"):
                content = self.env.get_template(template_name).render(**context)
                dest.write_text(content, encoding="utf-8")
            else:
                shutil.copyfile(item, dest)
