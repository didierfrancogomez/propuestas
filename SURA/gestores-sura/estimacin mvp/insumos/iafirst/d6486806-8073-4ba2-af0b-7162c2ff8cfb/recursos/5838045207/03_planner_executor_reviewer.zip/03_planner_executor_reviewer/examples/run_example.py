from pathlib import Path
from src.planner_executor_reviewer.config import load_config
from src.planner_executor_reviewer.models import AgentRequest
from src.planner_executor_reviewer.orchestrator import PlannerExecutorReviewer

base = Path(__file__).resolve().parents[1]
config = load_config(base)
orchestrator = PlannerExecutorReviewer(config['agent_manifest'], config['prompts'])
response = orchestrator.run(AgentRequest(user_id='demo.user', input_text='Genera una recomendación para un caso de reclamación'))
print(response.status)
print(response.answer)
print('review:', response.artifacts.get('review'))
