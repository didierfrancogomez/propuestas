from async_event_driven.application.ports.event_bus_port import EventBusPort, DomainEvent


class InMemoryEventBus(EventBusPort):
    async def publish(self, event: DomainEvent) -> None:
        print({"published_event": event.model_dump()})
