from importlib import resources
from pathlib import Path
from typing import Any

import yaml

from agent_blueprint.models import Profile, Capability


class CatalogLoader:
    def __init__(self, catalog_root: Path):
        self.catalog_root = catalog_root

    @classmethod
    def default(cls) -> "CatalogLoader":
        root = Path(str(resources.files("agent_blueprint") / "catalog"))
        return cls(root)

    def _read_yaml_files(self, folder: str) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for file in sorted((self.catalog_root / folder).glob("*.yaml")):
            data = yaml.safe_load(file.read_text(encoding="utf-8")) or {}
            key = data.get("name") or data.get("profile") or file.stem
            result[key] = data
        return result

    def load_profiles(self) -> dict[str, Profile]:
        return {k: Profile(**v) for k, v in self._read_yaml_files("profiles").items()}

    def load_capabilities(self) -> dict[str, Capability]:
        return {k: Capability(**v) for k, v in self._read_yaml_files("capabilities").items()}
