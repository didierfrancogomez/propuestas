from async_event_driven.bootstrap.dependency_container import DependencyContainer


class EventListener:
    """Scaffold for broker event consumption."""

    def __init__(self, container: DependencyContainer):
        self.container = container

    async def start(self) -> None:
        self.container.telemetry.event("agent.event_listener.started", {"agent": self.container.settings.agent_name})
        # Connect to broker and consume events here.
        pass
