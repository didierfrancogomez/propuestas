# Plantilla 03 - Planner-Executor-Reviewer

## Propósito

Referencia para flujos que requieren separación explícita entre planeación, ejecución y revisión antes de responder o actuar.

## Cuándo usar

- Riesgo medio o alto.
- Se requiere evidencia antes de responder.
- Hay acciones que pueden necesitar aprobación humana.
- Se requiere revisión independiente de calidad, seguridad o cumplimiento.

## Flujo de ejecución

```mermaid
flowchart TD
  A[AgentRequest] --> B[Planner crea plan]
  B --> C{Plan requiere acción sensible?}
  C -- No --> D[Executor ejecuta tools autorizadas]
  C -- Si --> D
  D --> E[Reviewer valida evidencia, seguridad y aprobación]
  E -->|Aprobado| F[Responder]
  E -->|Requiere humano| G[Human Supervisor]
  E -->|Rechazado| H[Detener o corregir]
```

## Componentes

| Componente | Archivo | Responsabilidad |
|---|---|---|
| Planner | `plan()` en `orchestrator.py` | Define pasos, tools y necesidad de aprobación. |
| Executor | `execute()` en `orchestrator.py` | Ejecuta herramientas autorizadas. |
| Reviewer | `review()` en `orchestrator.py` | Aprueba, rechaza o escala a humano. |
| Policy | `policy.py` | Valida tools, límites y entrada. |
| Prompts | `config/prompts.yaml` | Prompt del executor. |

## Ejecutar

```bash
python examples/run_example.py
pytest -q
```

## Criterios de aceptación

- Toda respuesta pasa por reviewer.
- Si se solicita aprobar una acción sensible, el resultado es `status=needs_human`.
- El plan queda en `artifacts.plan`.
- La revisión queda en `artifacts.review`.
- Las herramientas ejecutadas están autorizadas.

## Evolución a implementación real

- Incorporar LLM-as-a-judge solo como complemento, no como único control.
- Integrar motor de reglas para validaciones determinísticas.
- Agregar interfaz de supervisor humano.
- Persistir decisiones y aprobaciones para auditoría.
