import uvicorn

from single_agent_conversational.bootstrap.settings import Settings


def main() -> None:
    settings = Settings()
    uvicorn.run("single_agent_conversational.adapters.inbound.api_fastapi.app:app", host="0.0.0.0", port=settings.port, reload=False)


if __name__ == "__main__":
    main()
