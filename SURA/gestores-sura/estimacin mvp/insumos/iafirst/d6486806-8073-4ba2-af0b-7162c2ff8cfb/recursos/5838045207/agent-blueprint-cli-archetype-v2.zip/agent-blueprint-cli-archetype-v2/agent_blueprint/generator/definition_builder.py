import re
from pathlib import Path
from typing import Any

import yaml

from agent_blueprint.catalog.loader import CatalogLoader
from agent_blueprint.catalog.rules import apply_rules, validate_definition
from agent_blueprint.models import AgentDefinition


def normalize_package_name(name: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_]+", "_", name.strip().lower())
    value = re.sub(r"_+", "_", value).strip("_")
    if not value:
        value = "agent_runtime"
    if value[0].isdigit():
        value = f"agent_{value}"
    return value


def build_definition(data: dict[str, Any]) -> AgentDefinition:
    loader = CatalogLoader.default()
    profiles = loader.load_profiles()
    profile_name = data["profile"]
    if profile_name not in profiles:
        raise ValueError(f"Unknown profile: {profile_name}")

    profile = profiles[profile_name]
    features = profile.defaults.copy()
    features.update(data.get("features") or {})
    features.setdefault("prompt_management", "required")
    features.setdefault("observability", "otel")
    features.setdefault("policy_engine", "enabled")

    components = set(profile.includes)
    components = apply_rules(components, features)

    definition = AgentDefinition(
        name=data["name"],
        package_name=normalize_package_name(data["name"]),
        domain=data.get("domain") or "default-domain",
        owner=data.get("owner") or "default-team",
        profile=profile_name,
        output=Path(data.get("output") or f"./{data['name']}"),
        components=sorted(components),
        features=features,
    )
    validate_definition(definition)
    return definition


def load_definition_from_yaml(path: Path) -> AgentDefinition:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return build_definition(data)
