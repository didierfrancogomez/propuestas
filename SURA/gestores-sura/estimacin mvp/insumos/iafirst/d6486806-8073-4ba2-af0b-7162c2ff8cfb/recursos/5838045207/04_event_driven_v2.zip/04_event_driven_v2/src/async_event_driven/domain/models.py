from typing import Any, Literal
from pydantic import BaseModel, Field


class UserContext(BaseModel):
    user_id: str | None = None
    roles: list[str] = Field(default_factory=list)
    scopes: list[str] = Field(default_factory=list)
    tenant_id: str | None = None
    auth_source: str | None = None


class TraceContext(BaseModel):
    correlation_id: str
    trace_id: str | None = None
    span_id: str | None = None


class AgentRequest(BaseModel):
    input: str
    session_id: str
    user_context: UserContext
    trace_context: TraceContext


class AgentResponse(BaseModel):
    answer: str
    session_id: str
    trace_context: TraceContext
    metadata: dict[str, Any] = Field(default_factory=dict)


class ToolSpec(BaseModel):
    name: str
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    scopes_required: list[str] = Field(default_factory=list)
    risk_level: Literal["low", "medium", "high"] = "low"
    requires_confirmation: bool = False
    execution_mode: Literal["in_process", "mcp", "api", "remote_agent"] = "mcp"


class PolicyDecision(BaseModel):
    allowed: bool
    reason: str
    policy_id: str | None = None
