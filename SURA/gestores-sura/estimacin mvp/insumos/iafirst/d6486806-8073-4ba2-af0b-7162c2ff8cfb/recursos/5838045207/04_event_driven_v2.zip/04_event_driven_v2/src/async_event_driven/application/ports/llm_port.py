from typing import Protocol
from pydantic import BaseModel, Field
from async_event_driven.domain.models import TraceContext


class LLMRequest(BaseModel):
    prompt: str
    model_hint: str | None = None
    trace_context: TraceContext


class LLMResponse(BaseModel):
    content: str
    model: str | None = None
    usage: dict = Field(default_factory=dict)


class LLMPort(Protocol):
    async def complete(self, request: LLMRequest) -> LLMResponse:
        ...
