import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from async_event_driven.application.ports.tool_port import ToolPort, ToolExecutionRequest, ToolExecutionResult


class MCPClientAdapter(ToolPort):
    def __init__(self, mcp_gateway_url: str):
        self.mcp_gateway_url = mcp_gateway_url.rstrip("/")

    @retry(
        retry=retry_if_exception_type((httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.2, max=2.0),
        reraise=True,
    )
    async def execute(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.mcp_gateway_url}/tools/{request.tool_name}/execute",
                json=request.model_dump(),
            )
            response.raise_for_status()
            data = response.json()
            return ToolExecutionResult(**data)
