from langgraph.graph import END, StateGraph

from single_agent_conversational.adapters.outbound.langgraph.dependencies import GraphDependencies
from single_agent_conversational.adapters.outbound.langgraph.state.agent_state import AgentState


def make_respond_node(dependencies: GraphDependencies):
    async def respond_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.single_agent.respond",
            {"session_id": state.get("session_id")},
        )
        state["final_response"] = state.get("final_response") or "Single-agent graph scaffold executed."
        return state

    return respond_node


def build_graph(dependencies: GraphDependencies):
    """Build a minimal LangGraph single-agent graph."""
    graph = StateGraph(AgentState)
    graph.add_node("respond", make_respond_node(dependencies))
    graph.set_entry_point("respond")
    graph.add_edge("respond", END)
    return graph.compile()
