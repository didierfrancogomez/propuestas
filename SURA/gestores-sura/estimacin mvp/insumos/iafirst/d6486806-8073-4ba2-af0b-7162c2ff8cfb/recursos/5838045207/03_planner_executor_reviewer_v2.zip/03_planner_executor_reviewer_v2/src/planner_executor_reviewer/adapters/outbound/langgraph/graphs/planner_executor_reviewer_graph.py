from langgraph.graph import END, StateGraph

from planner_executor_reviewer.adapters.outbound.langgraph.dependencies import GraphDependencies
from planner_executor_reviewer.adapters.outbound.langgraph.state.agent_state import AgentState


def make_plan_node(dependencies: GraphDependencies):
    async def plan_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.planner_executor_reviewer.plan",
            {"session_id": state.get("session_id")},
        )
        state["plan"] = {"objective": state.get("input"), "steps": []}
        return state

    return plan_node


def make_execute_node(dependencies: GraphDependencies):
    async def execute_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.planner_executor_reviewer.execute",
            {"session_id": state.get("session_id")},
        )
        state["worker_results"] = []
        state["tool_calls"] = []
        return state

    return execute_node


def make_review_node(dependencies: GraphDependencies):
    async def review_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.planner_executor_reviewer.review",
            {"session_id": state.get("session_id")},
        )
        state["errors"] = []
        return state

    return review_node


def make_respond_node(dependencies: GraphDependencies):
    async def respond_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.planner_executor_reviewer.respond",
            {"session_id": state.get("session_id")},
        )
        state["final_response"] = (
            "Planner-executor-reviewer graph scaffold executed. "
            "Implement domain logic in plan, execute, review and respond nodes."
        )
        return state

    return respond_node


def build_graph(dependencies: GraphDependencies):
    """Build a minimal LangGraph planner-executor-reviewer graph.

    Flow: plan -> execute -> review -> respond -> END
    - plan: breaks down the objective into executable steps.
    - execute: runs each step using tools or workers via MCP.
    - review: evaluates the quality of execution results.
    - respond: consolidates the reviewed output into the final response.
    """
    graph = StateGraph(AgentState)

    graph.add_node("plan", make_plan_node(dependencies))
    graph.add_node("execute", make_execute_node(dependencies))
    graph.add_node("review", make_review_node(dependencies))
    graph.add_node("respond", make_respond_node(dependencies))

    graph.set_entry_point("plan")
    graph.add_edge("plan", "execute")
    graph.add_edge("execute", "review")
    graph.add_edge("review", "respond")
    graph.add_edge("respond", END)

    return graph.compile()
