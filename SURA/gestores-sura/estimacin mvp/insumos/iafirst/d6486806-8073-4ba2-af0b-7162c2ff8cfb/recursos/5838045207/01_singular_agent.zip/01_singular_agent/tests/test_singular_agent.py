from pathlib import Path
from src.singular_agent.config import load_config
from src.singular_agent.models import AgentRequest
from src.singular_agent.orchestrator import SingularAgentOrchestrator


def test_singular_agent_returns_answer_with_trace():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    orchestrator = SingularAgentOrchestrator(config['agent_manifest'], config['prompts'])
    response = orchestrator.run(AgentRequest(user_id='u1', input_text='Consulta conocimiento autorizado'))
    assert response.status == 'ok'
    assert response.answer
    assert any(t.step == 'tool.call' for t in response.trace)
    assert response.artifacts['session_id']


def test_singular_agent_blocks_policy_violation():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    orchestrator = SingularAgentOrchestrator(config['agent_manifest'], config['prompts'])
    response = orchestrator.run(AgentRequest(user_id='u1', input_text='quiero exfiltrar datos'))
    assert response.status == 'blocked'
