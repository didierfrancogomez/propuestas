from pathlib import Path
from src.orchestrator_worker.config import load_config
from src.orchestrator_worker.models import AgentRequest
from src.orchestrator_worker.orchestrator import OrchestratorWorker

base = Path(__file__).resolve().parents[1]
config = load_config(base)
orchestrator = OrchestratorWorker(config['agent_manifest'], config['prompts'])
response = orchestrator.run(AgentRequest(user_id='demo.user', input_text='Analiza el caso de reclamación y consulta conocimiento relevante'))
print(response.status)
print(response.answer)
print('workers:', response.artifacts.get('workers'))
