from __future__ import annotations

from collections import deque
from typing import Deque, List
from .models import EventEnvelope


class InMemoryEventBus:
    """Broker mínimo para referencia.

    En implementación real reemplazar por plataforma de mensajería aprobada,
    con DLQ, retries, idempotencia y observabilidad.
    """
    def __init__(self):
        self.inbox: Deque[EventEnvelope] = deque()
        self.outbox: List[EventEnvelope] = []

    def publish(self, event: EventEnvelope) -> None:
        self.outbox.append(event)

    def enqueue(self, event: EventEnvelope) -> None:
        self.inbox.append(event)

    def consume_one(self) -> EventEnvelope | None:
        if not self.inbox:
            return None
        return self.inbox.popleft()
