from typing import Protocol
from pydantic import BaseModel, Field


class RemoteAgentRequest(BaseModel):
    agent_id: str
    message: str
    metadata: dict = Field(default_factory=dict)


class RemoteAgentResponse(BaseModel):
    agent_id: str
    content: str
    metadata: dict = Field(default_factory=dict)


class RemoteAgentPort(Protocol):
    async def invoke(self, request: RemoteAgentRequest) -> RemoteAgentResponse:
        ...
