from fastapi import APIRouter, Depends, Request
from single_agent_conversational.adapters.inbound.a2a.schemas import A2AAgentCard, A2AAgentSkill, A2AAuthentication
from single_agent_conversational.bootstrap.settings import Settings

router = APIRouter()


def get_settings(request: Request) -> Settings:
    return request.app.state.container.settings


@router.get("/.well-known/agent-card.json", response_model=A2AAgentCard)
def agent_card(settings: Settings = Depends(get_settings)) -> A2AAgentCard:
    return A2AAgentCard(
        name="single-agent-conversational",
        description="Generated A2A AgentCard for single-agent-conversational",
        version="0.1.0",
        url=settings.public_agent_url,
        skills=[
            A2AAgentSkill(
                id="default_skill",
                name="Default skill",
                description="Replace with real agent skills",
            )
        ],
        capabilities={"streaming": False},
        authentication=A2AAuthentication(type="oauth2", scopes=["agents.invoke"]),
    )
