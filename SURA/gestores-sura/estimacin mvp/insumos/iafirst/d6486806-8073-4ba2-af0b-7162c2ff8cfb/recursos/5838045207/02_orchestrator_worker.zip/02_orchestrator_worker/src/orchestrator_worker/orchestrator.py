from __future__ import annotations

from .models import AgentRequest, AgentResponse, DecisionTrace
from .memory import InMemoryMemoryStore
from .prompts import PromptRegistry
from .policy import PolicyEngine, PolicyViolation
from .llm_client import MockLLMGateway
from .subagent import SubAgent


class OrchestratorWorker:
    """Patrón Orchestrator-Worker.

    El orquestador central conserva control y delega a workers especializados.
    """
    def __init__(self, manifest, prompts_config):
        self.memory = InMemoryMemoryStore()
        self.prompts = PromptRegistry(prompts_config)
        self.policy = PolicyEngine(manifest)
        self.llm = MockLLMGateway()
        self.workers = {
            'knowledge_worker': SubAgent('knowledge_worker', 'especialista_conocimiento', ['knowledge_search'], self.policy, self.prompts),
            'case_worker': SubAgent('case_worker', 'especialista_casos', ['case_lookup'], self.policy, self.prompts),
        }

    def _route(self, text: str):
        tasks = [{'worker': 'knowledge_worker', 'description': f'Buscar conocimiento relevante para: {text}'}]
        if 'caso' in text.lower() or 'reclamacion' in text.lower() or 'reclamación' in text.lower():
            tasks.append({'worker': 'case_worker', 'description': 'Consultar estado de caso o reclamación'})
        return tasks

    def run(self, request: AgentRequest) -> AgentResponse:
        trace = []
        session_id = request.session_id or request.correlation_id
        try:
            self.policy.validate_input(request.input_text)
            trace.append(DecisionTrace(step='orchestrator.start', decision='accepted', reason='Solicitud recibida por orquestador central'))
            self.memory.append(session_id, {'role': 'user', 'content': request.input_text})

            tasks = self._route(request.input_text)
            trace.append(DecisionTrace(step='router.plan', decision='delegate_to_workers', reason='Se identifican workers requeridos', metadata={'tasks': tasks}))

            worker_results = []
            for idx, task in enumerate(tasks, start=1):
                self.policy.validate_iterations(idx)
                worker = self.workers[task['worker']]
                result = worker.execute(request, task)
                worker_results.append(result)
                trace.append(DecisionTrace(step='handoff.return', decision=task['worker'], reason='Worker devuelve resultado al orquestador'))
                trace.extend(result['trace'])

            prompt = self.prompts.render('orchestrator_synthesis', user_input=request.input_text, worker_results=str(worker_results))
            answer = self.llm.complete(prompt, metadata={'intent': 'orchestrator_worker'})
            trace.append(DecisionTrace(step='orchestrator.finish', decision='synthesize', reason='El orquestador consolida resultados de workers'))
            return AgentResponse(correlation_id=request.correlation_id, answer=answer, status='ok', trace=trace, artifacts={'workers': [r['name'] for r in worker_results]})
        except PolicyViolation as e:
            trace.append(DecisionTrace(step='policy.violation', decision='blocked', reason=str(e)))
            return AgentResponse(correlation_id=request.correlation_id, answer='Solicitud bloqueada por política.', status='blocked', trace=trace)
