from typing import Protocol

from async_event_driven.domain.models import AgentRequest, AgentResponse


class OrchestrationPort(Protocol):
    async def run(self, request: AgentRequest) -> AgentResponse:
        ...
