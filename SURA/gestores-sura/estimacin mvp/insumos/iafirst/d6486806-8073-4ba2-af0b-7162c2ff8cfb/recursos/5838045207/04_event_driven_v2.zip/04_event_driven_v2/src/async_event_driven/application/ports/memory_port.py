from typing import Protocol, Literal
from pydantic import BaseModel, Field


class MemoryRecord(BaseModel):
    memory_id: str
    session_id: str
    memory_type: Literal["session", "working", "episodic", "long_term"]
    content: dict
    security_labels: list[str] = Field(default_factory=list)


class MemoryPort(Protocol):
    async def retrieve(self, session_id: str, query: dict) -> list[MemoryRecord]:
        """Retrieve records matching supported query filters.

        Supported scaffold filters: memory_type and security_labels.
        Adapters must document or reject unsupported filters.
        """
        ...

    async def persist(self, record: MemoryRecord) -> None:
        ...
