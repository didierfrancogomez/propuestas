from pathlib import Path
import yaml
from rich.console import Console

console = Console()


def validate_project(path: Path) -> bool:
    errors: list[str] = []
    metadata_path = path / ".agent-archetype.yaml"
    if not metadata_path.exists():
        errors.append("Missing .agent-archetype.yaml")
        metadata = {}
    else:
        metadata = yaml.safe_load(metadata_path.read_text(encoding="utf-8")) or {}

    src_dirs = list((path / "src").glob("*")) if (path / "src").exists() else []
    if not src_dirs:
        errors.append("Missing src package")

    components = set((metadata.get("components") or []))
    features = metadata.get("features") or {}

    if "prompt-management" not in components:
        errors.append("Prompt Management component is mandatory")

    if (path / "prompts").exists():
        errors.append("Local productive prompts directory is not allowed")

    if "tools-mcp" in components and "policy-engine" not in components:
        errors.append("MCP tools require policy-engine")

    if features.get("inbound") == "event":
        for required in ["event-broker", "idempotency"]:
            if required not in components:
                errors.append(f"Event-driven agents require {required}")

    if features.get("a2a") is True and "a2a" not in components:
        errors.append("A2A enabled but a2a component is missing")

    if errors:
        console.print("[bold red]Validation failed[/bold red]")
        for err in errors:
            console.print(f"- {err}")
        return False

    console.print("[bold green]Validation passed[/bold green]")
    return True
