from dataclasses import dataclass

from async_event_driven.application.ports.llm_port import LLMPort
from async_event_driven.application.ports.policy_port import PolicyPort
from async_event_driven.application.ports.telemetry_port import TelemetryPort

from async_event_driven.application.prompts.prompt_runtime import PromptRuntime


from async_event_driven.application.ports.tool_port import ToolPort


from async_event_driven.application.ports.memory_port import MemoryPort


from async_event_driven.application.ports.event_bus_port import EventBusPort



@dataclass(frozen=True)
class GraphDependencies:
    """Ports available to LangGraph node factories.

    Keep concrete adapters out of graph nodes. The dependency container builds this
    object once and passes it to build_graph().
    """

    telemetry: TelemetryPort
    policy_engine: PolicyPort
    llm: LLMPort | None = None

    prompt_runtime: PromptRuntime | None = None


    tools: ToolPort | None = None


    memory: MemoryPort | None = None


    event_bus: EventBusPort | None = None

