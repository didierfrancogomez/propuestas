from __future__ import annotations

from uuid import uuid4
from .models import AgentRequest, AgentResponse, DecisionTrace, EventEnvelope, ToolRequest
from .prompts import PromptRegistry
from .policy import PolicyEngine, PolicyViolation
from .llm_client import MockLLMGateway
from .mcp_client import MockMCPClient
from .event_bus import InMemoryEventBus


class EventDrivenAgent:
    """Patrón Event-Driven.

    El agente se activa por eventos y publica un resultado procesado.
    """
    def __init__(self, manifest, prompts_config, bus: InMemoryEventBus | None = None):
        self.prompts = PromptRegistry(prompts_config)
        self.policy = PolicyEngine(manifest)
        self.llm = MockLLMGateway()
        self.mcp = MockMCPClient()
        self.bus = bus or InMemoryEventBus()

    def handle_event(self, event: EventEnvelope) -> AgentResponse:
        trace = []
        try:
            text = event.payload.get('text', '')
            request = AgentRequest(user_id=event.payload.get('user_id', 'system'), input_text=text, correlation_id=event.correlation_id)
            self.policy.validate_input(request.input_text)
            trace.append(DecisionTrace(step='event.received', decision=event.event_type, reason='Evento consumido por listener', metadata={'producer': event.producer}))

            tool_name = 'knowledge_search'
            self.policy.validate_tool(tool_name)
            evidence = self.mcp.call(ToolRequest(tool_name=tool_name, payload={'query': text}, correlation_id=event.correlation_id, user_id=request.user_id))
            trace.append(DecisionTrace(step='event.tool', decision=tool_name, reason='Se consulta evidencia para evento', metadata=evidence.result))

            prompt = self.prompts.render('event_response', event_type=event.event_type, payload=str(event.payload), evidence=str(evidence.result))
            answer = self.llm.complete(prompt, metadata={'intent': 'event_driven'})
            result_event = EventEnvelope(event_type='agent.result.created', payload={'answer': answer, 'source_event': event.event_type}, correlation_id=event.correlation_id, producer='event_driven_agent')
            self.bus.publish(result_event)
            trace.append(DecisionTrace(step='event.published', decision='agent.result.created', reason='Resultado publicado para consumidores downstream'))
            return AgentResponse(correlation_id=event.correlation_id, answer=answer, status='ok', trace=trace, artifacts={'published_event': result_event.event_type})
        except PolicyViolation as e:
            trace.append(DecisionTrace(step='policy.violation', decision='blocked', reason=str(e)))
            return AgentResponse(correlation_id=event.correlation_id, answer='Evento bloqueado por política.', status='blocked', trace=trace)

    def poll_once(self) -> AgentResponse | None:
        event = self.bus.consume_one()
        if event is None:
            return None
        return self.handle_event(event)
