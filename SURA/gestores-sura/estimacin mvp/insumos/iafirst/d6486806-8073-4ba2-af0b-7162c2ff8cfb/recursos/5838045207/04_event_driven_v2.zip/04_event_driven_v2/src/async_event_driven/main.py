import uvicorn

from async_event_driven.bootstrap.settings import Settings


def main() -> None:
    settings = Settings()
    uvicorn.run("async_event_driven.adapters.inbound.api_fastapi.app:app", host="0.0.0.0", port=settings.port, reload=False)


if __name__ == "__main__":
    main()
