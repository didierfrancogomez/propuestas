def test_generated_project_imports():
    import single_agent_conversational
    assert single_agent_conversational.__version__ == "0.1.0"
