from typing import Protocol
from pydantic import BaseModel, Field
from orchestrator_worker.domain.models import TraceContext


class WorkerTask(BaseModel):
    worker_id: str
    task_type: str
    payload: dict
    trace_context: TraceContext


class WorkerResult(BaseModel):
    worker_id: str
    success: bool
    result: dict = Field(default_factory=dict)
    error: str | None = None


class WorkerPort(Protocol):
    async def execute(self, task: WorkerTask) -> WorkerResult:
        ...
