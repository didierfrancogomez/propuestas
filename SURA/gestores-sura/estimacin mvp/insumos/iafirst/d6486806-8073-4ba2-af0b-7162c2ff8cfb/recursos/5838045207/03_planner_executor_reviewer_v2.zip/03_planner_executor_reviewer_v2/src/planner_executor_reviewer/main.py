import uvicorn

from planner_executor_reviewer.bootstrap.settings import Settings


def main() -> None:
    settings = Settings()
    uvicorn.run("planner_executor_reviewer.adapters.inbound.api_fastapi.app:app", host="0.0.0.0", port=settings.port, reload=False)


if __name__ == "__main__":
    main()
