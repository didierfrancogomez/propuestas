# Plantilla 01 - Agente Singular

## Propósito

Referencia mínima para casos acotados donde un único centro de control interpreta la solicitud, consulta memoria, usa una herramienta autorizada y responde con trazabilidad.

## Cuándo usar

- Tarea bien delimitada.
- Pocas herramientas.
- Alta necesidad de trazabilidad.
- No se requiere handoff a especialistas.

## Flujo de ejecución

```mermaid
sequenceDiagram
  participant U as Usuario/Canal
  participant O as Orquestador Singular
  participant P as Policy/GuardRails
  participant M as Memoria
  participant T as MCP/Tool
  participant L as LLM Gateway
  U->>O: AgentRequest
  O->>P: validar entrada y permisos
  O->>M: leer/escribir contexto
  O->>T: knowledge_search
  O->>L: completar respuesta con prompt versionado
  O-->>U: AgentResponse + trace
```

## Componentes

| Componente | Archivo | Responsabilidad |
|---|---|---|
| Orquestador | `src/singular_agent/orchestrator.py` | Controla el flujo end-to-end. |
| Memoria | `src/singular_agent/memory.py` | Guarda contexto de sesión. |
| Prompts | `config/prompts.yaml` | Versiona prompts mínimos. |
| Policy | `src/singular_agent/policy.py` | Valida entrada, tools e iteraciones. |
| MCP mock | `src/singular_agent/mcp_client.py` | Simula herramientas corporativas. |
| LLM mock | `src/singular_agent/llm_client.py` | Simula LLM Gateway. |

## Ejecutar

```bash
python examples/run_example.py
pytest -q
```

## Criterios de aceptación

- La solicitud válida retorna `status=ok`.
- Se registra traza de validación, memoria, tool y respuesta.
- La tool invocada está autorizada en `agent_manifest.yaml`.
- Una entrada bloqueada por política retorna `status=blocked`.
- No hay dependencias reales a LLM, MCP ni base de datos.

## Evolución a implementación real

- Reemplazar `MockLLMGateway` por LLM Gateway corporativo.
- Reemplazar `MockMCPClient` por MCP Gateway o API gobernada.
- Reemplazar `InMemoryMemoryStore` por Cosmos DB, vector store o memoria aprobada.
- Integrar OpenTelemetry, correlation ID y logs estructurados.
