from langgraph.graph import END, StateGraph

from orchestrator_worker.adapters.outbound.langgraph.dependencies import GraphDependencies
from orchestrator_worker.adapters.outbound.langgraph.state.agent_state import AgentState


def make_plan_node(dependencies: GraphDependencies):
    async def plan_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.orchestrator_worker.plan",
            {"session_id": state.get("session_id")},
        )
        state["plan"] = {"objective": state.get("input"), "steps": []}
        state["worker_tasks"] = []
        return state

    return plan_node


def make_dispatch_node(dependencies: GraphDependencies):
    async def dispatch_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.orchestrator_worker.dispatch",
            {"session_id": state.get("session_id")},
        )
        state["worker_results"] = []
        state["tool_calls"] = []
        return state

    return dispatch_node


def make_finalize_node(dependencies: GraphDependencies):
    async def finalize_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.orchestrator_worker.finalize",
            {"session_id": state.get("session_id")},
        )
        state["final_response"] = (
            "Orchestrator-worker graph scaffold executed. "
            "Implement domain logic in plan, dispatch and finalize nodes."
        )
        return state

    return finalize_node


def build_graph(dependencies: GraphDependencies):
    """Build a minimal LangGraph orchestrator-worker graph.

    Flow: plan -> dispatch -> finalize -> END
    - plan: interprets the input and creates a work plan.
    - dispatch: sends tasks to workers or tools via MCP.
    - finalize: consolidates results into the final response.
    """
    graph = StateGraph(AgentState)

    graph.add_node("plan", make_plan_node(dependencies))
    graph.add_node("dispatch", make_dispatch_node(dependencies))
    graph.add_node("finalize", make_finalize_node(dependencies))

    graph.set_entry_point("plan")
    graph.add_edge("plan", "dispatch")
    graph.add_edge("dispatch", "finalize")
    graph.add_edge("finalize", END)

    return graph.compile()
