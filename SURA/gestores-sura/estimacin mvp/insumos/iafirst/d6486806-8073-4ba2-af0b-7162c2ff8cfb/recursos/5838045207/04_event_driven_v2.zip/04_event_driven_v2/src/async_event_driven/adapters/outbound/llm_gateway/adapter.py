import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from async_event_driven.application.ports.llm_port import LLMPort, LLMRequest, LLMResponse


class LLMGatewayAdapter(LLMPort):
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    @retry(
        retry=retry_if_exception_type((httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.2, max=2.0),
        reraise=True,
    )
    async def complete(self, request: LLMRequest) -> LLMResponse:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/v1/chat/completions",
                json={"prompt": request.prompt, "model_hint": request.model_hint},
            )
            response.raise_for_status()
            data = response.json()
            return LLMResponse(content=data.get("content", ""), model=data.get("model"), usage=data.get("usage", {}))
