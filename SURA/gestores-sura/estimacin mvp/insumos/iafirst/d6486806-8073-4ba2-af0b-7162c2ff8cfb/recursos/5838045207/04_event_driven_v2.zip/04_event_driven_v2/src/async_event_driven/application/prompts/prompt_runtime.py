from async_event_driven.application.ports.prompt_port import PromptPort, RenderedPrompt
from async_event_driven.domain.models import TraceContext


class PromptRuntime:
    def __init__(self, prompt_port: PromptPort, environment: str, version_policy: str = "approved"):
        self.prompt_port = prompt_port
        self.environment = environment
        self.version_policy = version_policy

    async def resolve(self, prompt_id: str, variables: dict, trace_context: TraceContext) -> RenderedPrompt:
        return await self.prompt_port.get_prompt(
            prompt_id=prompt_id,
            version_policy=self.version_policy,
            environment=self.environment,
            variables=variables,
            trace_context=trace_context,
        )
