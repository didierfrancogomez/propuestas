# Agent Blueprint CLI

CLI para generar proyectos Python de Agentic Runtime segun perfiles de arquitectura.

## Objetivo

Este repositorio no es el proyecto final del agente. Es una fabrica de proyectos.
El desarrollador ejecuta el CLI, selecciona un perfil y capacidades, y el CLI genera un proyecto limpio.

## Instalacion local

```bash
pip install -e .
```

## Quick start

```bash
agent-blueprint list-profiles
agent-blueprint create
```

Modo no interactivo:

```bash
agent-blueprint create \
  --name agente-siniestros \
  --profile orchestrator-worker \
  --domain seguros \
  --owner equipo-siniestros \
  --output ./agente-siniestros \
  --non-interactive
```

## Parametros de creacion

Al ejecutar `agent-blueprint create` en modo interactivo, el CLI solicita los siguientes parametros.
Cada valor queda reflejado en `.agent-archetype.yaml` y determina que componentes, configuracion y archivos se generan.

| Parametro | Valores / ejemplo | Impacto en el proyecto generado |
| --- | --- | --- |
| Agent project name | `agente-siniestros` | Define el nombre del proyecto, el directorio por defecto de salida y el `package_name` Python normalizado. Por ejemplo, `agente-siniestros` genera un paquete como `agente_siniestros`. |
| Business domain | `seguros`, `salud`, `default-domain` | Registra el dominio funcional del agente en la metadata del arquetipo. Sirve para trazabilidad, ownership funcional y clasificacion del agente generado. |
| Owning team | `equipo-siniestros`, `default-team` | Registra el equipo responsable en la metadata del proyecto generado. Ayuda a gobierno, soporte y auditoria del runtime. |
| Select implementation profile | `single-agent-conversational`, `transactional-tools`, `orchestrator-worker`, `planner-executor-reviewer`, `async-event-driven` | Selecciona la arquitectura base. Cada perfil trae componentes obligatorios, como grafo LangGraph, inbound HTTP o event-driven, MCP tools, memoria episodica, broker de eventos o evaluacion. |
| Inbound channel | `http` o `event` | `http` genera entrada FastAPI. `event` genera listener de eventos, event broker in-memory e idempotencia. |
| Tools mode | `none` o `mcp` | `none` no agrega herramientas externas. `mcp` agrega puerto de tools, adaptador cliente MCP y exige Policy Engine y observabilidad para gobernar llamadas a herramientas. |
| Memory mode | `session` o `episodic` | `session` conserva solo el `session_id` del request y el estado transitorio del grafo; no genera puerto ni adaptador de memoria. `episodic` agrega el componente `memory-episodic`, con `MemoryPort`, `MemoryRecord` e `InMemoryMemoryAdapter` para persistir y consultar recuerdos por `session_id`, `memory_type` y etiquetas de seguridad. |
| Enable A2A / AgentCard? | `true` o `false` | Cuando es `true`, agrega configuracion A2A, schemas y rutas para exponer AgentCard y capacidades de interoperabilidad entre agentes. |
| Generate Internal MCP Server? | `true` o `false` | Cuando es `true`, genera un servidor MCP interno con estructura base de tools propias para que otros clientes o agentes puedan invocarlas. |
| Output directory | `./agente-siniestros` | Define donde se escribe el proyecto final. Si no se indica, usa `./<Agent project name>`. |

En modo no interactivo (`--non-interactive`) solo se reciben por flags `--name`, `--profile`, `--domain`, `--owner` y `--output`.
Las capacidades restantes se toman de los defaults del perfil. Para controlar todas las capacidades de forma declarativa use un archivo YAML con `--config`.

### Memoria session vs episodic

La diferencia principal esta en el alcance de implementacion que genera el arquetipo:

- `session`: orientada al contexto inmediato de una conversacion o ejecucion. El proyecto mantiene `session_id` en los modelos, telemetria y estado del grafo, pero no crea un repositorio de memoria. Es adecuada cuando el agente no necesita recuperar informacion de interacciones previas mas alla del estado runtime de la solicitud.
- `episodic`: orientada a recordar eventos o experiencias relevantes. El proyecto agrega un puerto de memoria y un adaptador in-memory de referencia para guardar y recuperar `MemoryRecord`. Es el punto de extension para reemplazar la memoria local por Redis, base de datos, vector store u otro almacenamiento persistente.

Actualmente el wizard presenta `session` y `episodic` como seleccion excluyente. En la practica, un proyecto generado con `episodic` puede manejar recuerdos de tipo `session` y `episodic`, porque `MemoryRecord.memory_type` acepta ambos valores. Si se requiere tener ambos enfoques explicitamente, la recomendacion es seleccionar `episodic` y usar `memory_type="session"` para datos temporales de sesion y `memory_type="episodic"` para recuerdos reutilizables. El modo `session` por si solo no genera el componente de memoria.

## Prompt Management

Prompt Management es obligatorio. El proyecto generado no contiene prompts productivos locales.
Los prompts se referencian por prompt_id y version_policy y se resuelven mediante PromptPort.

## Comandos

```bash
agent-blueprint create
agent-blueprint list-profiles
agent-blueprint list-capabilities
agent-blueprint validate --path ./agente-siniestros
agent-blueprint doctor
```

## Perfiles incluidos

- single-agent-conversational
- transactional-tools
- orchestrator-worker
- planner-executor-reviewer
- async-event-driven

## Regla de diseno

El CLI genera por inclusion, no limpia por exclusion. Cada perfil define los componentes requeridos.
