from orchestrator_worker.application.ports.prompt_port import PromptPort, RenderedPrompt
from orchestrator_worker.domain.models import TraceContext
from orchestrator_worker.adapters.outbound.prompt_management.client import PromptManagementClient


class PromptManagementAdapter(PromptPort):
    def __init__(self, client: PromptManagementClient):
        self.client = client

    async def get_prompt(
        self,
        prompt_id: str,
        version_policy: str,
        environment: str,
        variables: dict,
        trace_context: TraceContext,
    ) -> RenderedPrompt:
        payload = {
            "prompt_id": prompt_id,
            "version_policy": version_policy,
            "environment": environment,
            "variables": variables,
            "trace_context": trace_context.model_dump(),
        }
        data = await self.client.render_prompt(payload)
        return RenderedPrompt(
            prompt_id=data["prompt_id"],
            version=data["version"],
            content=data["content"],
            metadata=data.get("metadata", {}),
        )
