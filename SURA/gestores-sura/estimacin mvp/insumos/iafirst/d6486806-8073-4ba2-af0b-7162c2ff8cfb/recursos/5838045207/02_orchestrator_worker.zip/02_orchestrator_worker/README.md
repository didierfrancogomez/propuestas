# Plantilla 02 - Orchestrator-Worker

## Propósito

Referencia para escenarios donde un orquestador central conserva el control y delega tareas a subagentes especializados.

## Cuándo usar

- Hay varios dominios o capacidades especializadas.
- Se requiere handoff controlado.
- Se quiere crecer por módulos sin activar agentes distribuidos libres.
- Se requiere consolidación central de resultados.

## Flujo de ejecución

```mermaid
sequenceDiagram
  participant U as Usuario/Canal
  participant O as Orchestrator
  participant R as Router
  participant W1 as Knowledge Worker
  participant W2 as Case Worker
  participant G as GuardRails
  participant L as LLM Gateway
  U->>O: AgentRequest
  O->>G: validar solicitud
  O->>R: plan de delegación
  R-->>O: tareas por worker
  O->>W1: handoff mínimo necesario
  W1-->>O: resultado estructurado
  O->>W2: handoff condicional
  W2-->>O: resultado estructurado
  O->>L: síntesis final
  O-->>U: respuesta consolidada + trace
```

## Componentes

| Componente | Archivo | Responsabilidad |
|---|---|---|
| Orchestrator | `src/orchestrator_worker/orchestrator.py` | Planea, enruta, delega y consolida. |
| Subagente | `src/orchestrator_worker/subagent.py` | Ejecuta una tarea especializada. |
| Protocolos | `src/orchestrator_worker/models.py` | Define AgentRequest, AgentResponse, ToolRequest. |
| Policy | `src/orchestrator_worker/policy.py` | Controla permisos y límites. |
| Prompts | `config/prompts.yaml` | Prompts de worker y síntesis. |

## Ejecutar

```bash
python examples/run_example.py
pytest -q
```

## Criterios de aceptación

- El router identifica al menos un worker.
- El handoff queda trazado con `handoff.return`.
- Los workers retornan salida estructurada.
- El orquestador, no el worker, consolida la respuesta final.
- Un worker no puede usar tools no autorizadas.

## Evolución a implementación real

- Separar workers en servicios independientes solo si la complejidad lo exige.
- Incorporar contratos OpenAPI/AsyncAPI para handoff.
- Incorporar colas si los workers son asincrónicos.
- Agregar métricas por worker: latencia, costo, éxito y error.
