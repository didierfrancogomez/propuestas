from async_event_driven.application.ports.memory_port import MemoryPort, MemoryRecord


class InMemoryMemoryAdapter(MemoryPort):
    def __init__(self):
        self.records: list[MemoryRecord] = []

    async def retrieve(self, session_id: str, query: dict) -> list[MemoryRecord]:
        unsupported = set(query) - {"memory_type", "security_labels"}
        if unsupported:
            raise ValueError(f"Unsupported memory query filters: {sorted(unsupported)}")

        records = [r for r in self.records if r.session_id == session_id]
        if memory_type := query.get("memory_type"):
            records = [r for r in records if r.memory_type == memory_type]
        if security_labels := query.get("security_labels"):
            required_labels = set(security_labels)
            records = [r for r in records if required_labels.issubset(set(r.security_labels))]
        return records

    async def persist(self, record: MemoryRecord) -> None:
        self.records.append(record)
