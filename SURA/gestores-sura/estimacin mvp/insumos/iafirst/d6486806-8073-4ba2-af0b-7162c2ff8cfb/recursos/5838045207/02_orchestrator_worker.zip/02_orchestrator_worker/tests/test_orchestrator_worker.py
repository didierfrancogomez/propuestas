from pathlib import Path
from src.orchestrator_worker.config import load_config
from src.orchestrator_worker.models import AgentRequest
from src.orchestrator_worker.orchestrator import OrchestratorWorker


def test_orchestrator_worker_delegates_to_specialists():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    orchestrator = OrchestratorWorker(config['agent_manifest'], config['prompts'])
    response = orchestrator.run(AgentRequest(user_id='u1', input_text='Analiza un caso de reclamación'))
    assert response.status == 'ok'
    assert set(response.artifacts['workers']) == {'knowledge_worker', 'case_worker'}
    assert any(t.step == 'router.plan' for t in response.trace)
    assert any(t.step == 'handoff.return' for t in response.trace)
