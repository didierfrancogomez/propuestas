from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="AGENT_",
        env_file=".env",
        env_file_encoding="utf-8",
    )

    agent_name: str = "async-event-driven"
    port: int = 8080
    environment: str = "local"
    prompt_management_url: str | None = None
    llm_gateway_url: str | None = None
    mcp_gateway_url: str | None = None
    public_agent_url: str = "http://localhost:8080"
