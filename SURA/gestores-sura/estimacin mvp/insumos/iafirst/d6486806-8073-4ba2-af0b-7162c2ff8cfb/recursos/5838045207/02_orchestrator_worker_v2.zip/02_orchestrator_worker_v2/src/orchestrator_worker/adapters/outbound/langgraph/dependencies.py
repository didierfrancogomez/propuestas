from dataclasses import dataclass

from orchestrator_worker.application.ports.llm_port import LLMPort
from orchestrator_worker.application.ports.policy_port import PolicyPort
from orchestrator_worker.application.ports.telemetry_port import TelemetryPort

from orchestrator_worker.application.prompts.prompt_runtime import PromptRuntime


from orchestrator_worker.application.ports.tool_port import ToolPort


from orchestrator_worker.application.ports.memory_port import MemoryPort




@dataclass(frozen=True)
class GraphDependencies:
    """Ports available to LangGraph node factories.

    Keep concrete adapters out of graph nodes. The dependency container builds this
    object once and passes it to build_graph().
    """

    telemetry: TelemetryPort
    policy_engine: PolicyPort
    llm: LLMPort | None = None

    prompt_runtime: PromptRuntime | None = None


    tools: ToolPort | None = None


    memory: MemoryPort | None = None


