from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from agent_blueprint.commands.create import create_project
from agent_blueprint.commands.validate import validate_project
from agent_blueprint.catalog.loader import CatalogLoader
from agent_blueprint.doctor import run_doctor

app = typer.Typer(help="Agent Blueprint runtime project generator")
console = Console()


@app.command("create")
def create(
    name: Optional[str] = typer.Option(None, help="Agent project name"),
    profile: Optional[str] = typer.Option(None, help="Profile name"),
    domain: Optional[str] = typer.Option(None, help="Business domain"),
    owner: Optional[str] = typer.Option(None, help="Owning team"),
    output: Optional[Path] = typer.Option(None, help="Output directory"),
    config: Optional[Path] = typer.Option(None, help="Declarative agent definition YAML"),
    non_interactive: bool = typer.Option(False, help="Disable wizard mode"),
):
    create_project(
        name=name,
        profile=profile,
        domain=domain,
        owner=owner,
        output=output,
        config_path=config,
        non_interactive=non_interactive,
    )


@app.command("list-profiles")
def list_profiles():
    loader = CatalogLoader.default()
    profiles = loader.load_profiles()
    table = Table(title="Available agent profiles")
    table.add_column("Profile")
    table.add_column("Description")
    table.add_column("Includes")
    for p in profiles.values():
        table.add_row(p.name, p.description, ", ".join(p.includes))
    console.print(table)


@app.command("list-capabilities")
def list_capabilities():
    loader = CatalogLoader.default()
    capabilities = loader.load_capabilities()
    table = Table(title="Available capabilities")
    table.add_column("Capability")
    table.add_column("Description")
    table.add_column("Components")
    for c in capabilities.values():
        table.add_row(c.name, c.description, ", ".join(c.components))
    console.print(table)


@app.command("validate")
def validate(
    path: Path = typer.Option(Path.cwd(), help="Path to generated agent project"),
):
    ok = validate_project(path)
    if not ok:
        raise typer.Exit(1)


@app.command("doctor")
def doctor():
    run_doctor()


if __name__ == "__main__":
    app()
