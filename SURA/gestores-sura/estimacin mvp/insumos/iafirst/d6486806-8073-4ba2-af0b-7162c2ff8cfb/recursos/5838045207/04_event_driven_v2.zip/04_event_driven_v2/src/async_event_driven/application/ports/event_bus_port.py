from typing import Protocol
from pydantic import BaseModel


class DomainEvent(BaseModel):
    event_id: str
    event_type: str
    payload: dict
    correlation_id: str


class EventBusPort(Protocol):
    async def publish(self, event: DomainEvent) -> None:
        ...
