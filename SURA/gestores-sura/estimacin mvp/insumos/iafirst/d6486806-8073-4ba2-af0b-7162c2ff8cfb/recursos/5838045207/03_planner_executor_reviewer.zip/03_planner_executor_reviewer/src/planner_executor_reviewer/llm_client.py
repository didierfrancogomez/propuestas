from __future__ import annotations

from typing import Dict, Any


class MockLLMGateway:
    """Cliente LLM de referencia.

    En implementación real reemplazar por LLM Gateway corporativo,
    con autenticación, control de tokens, costos, seguridad y trazabilidad.
    """
    def complete(self, prompt: str, metadata: Dict[str, Any] | None = None) -> str:
        metadata = metadata or {}
        intent = metadata.get('intent', 'general')
        return f'[mock-llm:{intent}] Respuesta generada con base en el prompt: {prompt[:180]}'
