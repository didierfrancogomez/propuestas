from typing import Any
from opentelemetry import trace
from orchestrator_worker.application.ports.telemetry_port import TelemetryPort


class OpenTelemetryAdapter(TelemetryPort):
    def __init__(self):
        self.tracer = trace.get_tracer("orchestrator_worker")

    def event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        span = trace.get_current_span()
        span.add_event(name, attributes or {})

    def error(self, name: str, error: Exception, attributes: dict[str, Any] | None = None) -> None:
        span = trace.get_current_span()
        span.record_exception(error, attributes or {})
        span.add_event(name, attributes or {})
