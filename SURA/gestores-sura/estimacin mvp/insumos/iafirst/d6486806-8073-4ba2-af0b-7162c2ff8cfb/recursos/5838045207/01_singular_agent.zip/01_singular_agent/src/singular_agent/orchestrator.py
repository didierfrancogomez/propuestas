from __future__ import annotations

from .models import AgentRequest, AgentResponse, DecisionTrace, ToolRequest
from .memory import InMemoryMemoryStore
from .prompts import PromptRegistry
from .policy import PolicyEngine, PolicyViolation
from .llm_client import MockLLMGateway
from .mcp_client import MockMCPClient


class SingularAgentOrchestrator:
    """Patrón Agente Singular.

    Un único centro de control decide, consulta herramientas permitidas y responde.
    """
    def __init__(self, manifest, prompts_config):
        self.memory = InMemoryMemoryStore()
        self.prompts = PromptRegistry(prompts_config)
        self.policy = PolicyEngine(manifest)
        self.llm = MockLLMGateway()
        self.mcp = MockMCPClient()

    def run(self, request: AgentRequest) -> AgentResponse:
        trace = []
        session_id = request.session_id or request.correlation_id
        try:
            self.policy.validate_input(request.input_text)
            trace.append(DecisionTrace(step='input.validation', decision='accepted', reason='La entrada cumple políticas mínimas'))

            self.memory.append(session_id, {'role': 'user', 'content': request.input_text})
            recent_memory = self.memory.get_recent(session_id)
            trace.append(DecisionTrace(step='memory.read', decision='loaded_recent_context', reason='Se recupera memoria corta de sesión', metadata={'items': len(recent_memory)}))

            tool_name = 'knowledge_search'
            self.policy.validate_tool(tool_name)
            tool_response = self.mcp.call(ToolRequest(tool_name=tool_name, payload={'query': request.input_text}, correlation_id=request.correlation_id, user_id=request.user_id))
            trace.append(DecisionTrace(step='tool.call', decision=tool_name, reason='Se consulta conocimiento autorizado', metadata=tool_response.result))

            prompt = self.prompts.render('singular_response', user_input=request.input_text, memory=str(recent_memory), evidence=str(tool_response.result))
            answer = self.llm.complete(prompt, metadata={'intent': 'singular'})
            self.memory.append(session_id, {'role': 'assistant', 'content': answer})
            trace.append(DecisionTrace(step='response.final', decision='answer_user', reason='Respuesta generada por agente singular'))
            return AgentResponse(correlation_id=request.correlation_id, answer=answer, status='ok', trace=trace, artifacts={'session_id': session_id})
        except PolicyViolation as e:
            trace.append(DecisionTrace(step='policy.violation', decision='blocked', reason=str(e)))
            return AgentResponse(correlation_id=request.correlation_id, answer='Solicitud bloqueada por política.', status='blocked', trace=trace)
