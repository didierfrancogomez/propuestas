def test_generated_project_imports():
    import async_event_driven
    assert async_event_driven.__version__ == "0.1.0"
