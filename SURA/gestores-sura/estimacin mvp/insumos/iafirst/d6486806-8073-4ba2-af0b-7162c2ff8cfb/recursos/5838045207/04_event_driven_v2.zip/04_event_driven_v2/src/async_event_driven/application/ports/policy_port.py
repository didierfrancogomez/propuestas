from typing import Protocol
from async_event_driven.domain.models import PolicyDecision, UserContext, ToolSpec


class PolicyPort(Protocol):
    async def authorize_tool(self, user_context: UserContext, tool: ToolSpec) -> PolicyDecision:
        ...
