from typing import Protocol

from planner_executor_reviewer.domain.models import AgentRequest, AgentResponse


class OrchestrationPort(Protocol):
    async def run(self, request: AgentRequest) -> AgentResponse:
        ...
