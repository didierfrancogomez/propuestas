from typing import Any
from opentelemetry import trace
from single_agent_conversational.application.ports.telemetry_port import TelemetryPort


class OpenTelemetryAdapter(TelemetryPort):
    def __init__(self):
        self.tracer = trace.get_tracer("single_agent_conversational")

    def event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        span = trace.get_current_span()
        span.add_event(name, attributes or {})

    def error(self, name: str, error: Exception, attributes: dict[str, Any] | None = None) -> None:
        span = trace.get_current_span()
        span.record_exception(error, attributes or {})
        span.add_event(name, attributes or {})
