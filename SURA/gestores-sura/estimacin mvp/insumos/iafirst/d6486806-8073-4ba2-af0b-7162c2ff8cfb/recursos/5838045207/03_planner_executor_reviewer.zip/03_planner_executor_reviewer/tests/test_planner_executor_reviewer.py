from pathlib import Path
from src.planner_executor_reviewer.config import load_config
from src.planner_executor_reviewer.models import AgentRequest
from src.planner_executor_reviewer.orchestrator import PlannerExecutorReviewer


def test_planner_executor_reviewer_approves_non_sensitive_flow():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    orchestrator = PlannerExecutorReviewer(config['agent_manifest'], config['prompts'])
    response = orchestrator.run(AgentRequest(user_id='u1', input_text='Genera una recomendación para caso de reclamación'))
    assert response.status == 'ok'
    assert response.artifacts['review']['approved'] is True
    assert any(t.step == 'reviewer.finish' for t in response.trace)


def test_planner_executor_reviewer_requires_human_for_sensitive_action():
    base = Path(__file__).resolve().parents[1]
    config = load_config(base)
    orchestrator = PlannerExecutorReviewer(config['agent_manifest'], config['prompts'])
    response = orchestrator.run(AgentRequest(user_id='u1', input_text='aprobar pago de reclamación'))
    assert response.status == 'needs_human'
    assert response.artifacts['review']['human_required'] is True
