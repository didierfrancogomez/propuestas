from async_event_driven.application.ports.policy_port import PolicyPort
from async_event_driven.domain.models import PolicyDecision, ToolSpec, UserContext


class PolicyEngineAdapter(PolicyPort):
    async def authorize_tool(self, user_context: UserContext, tool: ToolSpec) -> PolicyDecision:
        missing = [scope for scope in tool.scopes_required if scope not in user_context.scopes]
        if missing:
            return PolicyDecision(allowed=False, reason=f"Missing scopes: {missing}")
        return PolicyDecision(allowed=True, reason="Allowed by default scaffold policy")
