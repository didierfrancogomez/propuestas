from typing import Protocol
from pydantic import BaseModel, Field


class EvaluationRequest(BaseModel):
    input: str
    output: str
    criteria: list[str]


class EvaluationResult(BaseModel):
    passed: bool
    score: float
    details: dict = Field(default_factory=dict)


class EvaluationPort(Protocol):
    async def evaluate(self, request: EvaluationRequest) -> EvaluationResult:
        ...
