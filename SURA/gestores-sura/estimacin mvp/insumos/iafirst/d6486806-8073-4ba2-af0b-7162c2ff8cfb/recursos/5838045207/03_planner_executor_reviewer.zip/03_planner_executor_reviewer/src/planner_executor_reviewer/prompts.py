from __future__ import annotations

from typing import Dict, Any


class PromptRegistry:
    def __init__(self, prompts_config: Dict[str, Any]):
        self.prompts = prompts_config.get('prompts', {})

    def render(self, prompt_name: str, **kwargs: Any) -> str:
        if prompt_name not in self.prompts:
            raise KeyError(f'Prompt no registrado: {prompt_name}')
        template = self.prompts[prompt_name]['template']
        return template.format(**kwargs)
