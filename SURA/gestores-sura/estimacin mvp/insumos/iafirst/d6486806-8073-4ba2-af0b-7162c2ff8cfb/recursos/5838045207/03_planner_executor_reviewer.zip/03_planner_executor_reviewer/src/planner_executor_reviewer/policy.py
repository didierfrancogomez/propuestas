from __future__ import annotations

from typing import Any, Dict, Iterable


class PolicyViolation(Exception):
    pass


class PolicyEngine:
    def __init__(self, manifest: Dict[str, Any]):
        self.manifest = manifest
        self.allowed_tools = set(manifest.get('allowed_tools', []))
        self.blocked_terms = set(manifest.get('blocked_terms', []))
        self.max_iterations = int(manifest.get('limits', {}).get('max_iterations', 3))

    def validate_input(self, text: str) -> None:
        lowered = text.lower()
        for term in self.blocked_terms:
            if term.lower() in lowered:
                raise PolicyViolation(f'Entrada bloqueada por política: {term}')

    def validate_tool(self, tool_name: str) -> None:
        if tool_name not in self.allowed_tools:
            raise PolicyViolation(f'Tool no autorizada: {tool_name}')

    def validate_iterations(self, count: int) -> None:
        if count > self.max_iterations:
            raise PolicyViolation('Se excedió el límite de iteraciones')
