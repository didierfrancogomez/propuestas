from typing import Any

from single_agent_conversational.application.ports.telemetry_port import TelemetryPort


class FakeTelemetry(TelemetryPort):
    def __init__(self):
        self.events: list[tuple[str, dict[str, Any]]] = []
        self.errors: list[tuple[str, Exception, dict[str, Any]]] = []

    def event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        self.events.append((name, attributes or {}))

    def error(self, name: str, error: Exception, attributes: dict[str, Any] | None = None) -> None:
        self.errors.append((name, error, attributes or {}))
