from pathlib import Path
from typing import Any

from rich.console import Console
from agent_blueprint.catalog.loader import CatalogLoader

console = Console()


def _prompt_text(message: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{message}{suffix}: ").strip()
    return value or (default or "")


def _prompt_select(message: str, choices: list[str], default: str | None = None) -> str:
    console.print(f"\n{message}")
    for i, choice in enumerate(choices, start=1):
        marker = "*" if choice == default else " "
        console.print(f"  {i}. {choice} {marker}")
    raw = input(f"Select option [default: {default or choices[0]}]: ").strip()
    if not raw:
        return default or choices[0]
    return choices[int(raw) - 1]


def _prompt_bool(message: str, default: bool = False) -> bool:
    raw = input(f"{message} [{'Y/n' if default else 'y/N'}]: ").strip().lower()
    if not raw:
        return default
    return raw in {"y", "yes", "s", "si"}


def run_wizard() -> dict[str, Any]:
    loader = CatalogLoader.default()
    profiles = loader.load_profiles()

    try:
        from InquirerPy import inquirer

        name = inquirer.text(message="Agent project name:").execute()
        domain = inquirer.text(message="Business domain:", default="default-domain").execute()
        owner = inquirer.text(message="Owning team:", default="default-team").execute()
        profile = inquirer.select(
            message="Select implementation profile:",
            choices=list(profiles.keys()),
        ).execute()
        inbound = inquirer.select(
            message="Inbound channel:",
            choices=["http", "event"],
            default=profiles[profile].defaults.get("inbound", "http"),
        ).execute()
        tools = inquirer.select(
            message="Tools mode:",
            choices=["none", "mcp"],
            default=profiles[profile].defaults.get("tools", "none"),
        ).execute()
        memory = inquirer.select(
            message="Memory mode:",
            choices=["session", "episodic"],
            default=profiles[profile].defaults.get("memory", "session"),
        ).execute()
        a2a = inquirer.confirm(message="Enable A2A / AgentCard?", default=False).execute()
        internal_mcp_server = inquirer.confirm(message="Generate Internal MCP Server?", default=False).execute()
        output = inquirer.text(message="Output directory:", default=f"./{name}").execute()
    except Exception:
        name = _prompt_text("Agent project name")
        domain = _prompt_text("Business domain", "default-domain")
        owner = _prompt_text("Owning team", "default-team")
        profile = _prompt_select("Select implementation profile", list(profiles.keys()))
        inbound = _prompt_select("Inbound channel", ["http", "event"], profiles[profile].defaults.get("inbound", "http"))
        tools = _prompt_select("Tools mode", ["none", "mcp"], profiles[profile].defaults.get("tools", "none"))
        memory = _prompt_select("Memory mode", ["session", "episodic"], profiles[profile].defaults.get("memory", "session"))
        a2a = _prompt_bool("Enable A2A / AgentCard?", False)
        internal_mcp_server = _prompt_bool("Generate Internal MCP Server?", False)
        output = _prompt_text("Output directory", f"./{name}")

    return {
        "name": name,
        "domain": domain,
        "owner": owner,
        "profile": profile,
        "output": Path(output),
        "features": {
            "inbound": inbound,
            "tools": tools,
            "memory": memory,
            "a2a": a2a,
            "internal_mcp_server": internal_mcp_server,
            "prompt_management": "required",
            "observability": "otel",
            "policy_engine": "enabled",
        },
    }
