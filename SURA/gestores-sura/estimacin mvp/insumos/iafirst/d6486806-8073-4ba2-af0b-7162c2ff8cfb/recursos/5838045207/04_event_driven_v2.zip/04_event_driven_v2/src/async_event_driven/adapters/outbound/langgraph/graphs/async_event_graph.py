from langgraph.graph import END, StateGraph

from async_event_driven.adapters.outbound.langgraph.dependencies import GraphDependencies
from async_event_driven.adapters.outbound.langgraph.state.agent_state import AgentState


def make_execute_event_node(dependencies: GraphDependencies):
    async def execute_event_node(state: AgentState) -> AgentState:
        dependencies.telemetry.event(
            "agent.graph.async_event.execute",
            {"session_id": state.get("session_id")},
        )
        state["final_response"] = state.get("final_response") or "Async event-driven graph scaffold executed."
        return state

    return execute_event_node


def build_graph(dependencies: GraphDependencies):
    """Build a minimal LangGraph async event-driven graph."""
    graph = StateGraph(AgentState)
    graph.add_node("execute_event", make_execute_event_node(dependencies))
    graph.set_entry_point("execute_event")
    graph.add_edge("execute_event", END)
    return graph.compile()
