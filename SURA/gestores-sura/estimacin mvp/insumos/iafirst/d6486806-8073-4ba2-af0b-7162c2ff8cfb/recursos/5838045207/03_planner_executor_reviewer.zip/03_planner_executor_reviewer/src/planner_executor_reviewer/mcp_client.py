from __future__ import annotations

from typing import Dict, Any
from .models import ToolRequest, ToolResponse


class MockMCPClient:
    """Cliente MCP de referencia.

    Simula herramientas controladas. En implementación real debe invocar
    MCP Gateway o APIs corporativas con identidad propagada y timeouts.
    """
    def call(self, request: ToolRequest) -> ToolResponse:
        if request.tool_name == 'knowledge_search':
            query = request.payload.get('query', '')
            return ToolResponse(
                tool_name=request.tool_name,
                ok=True,
                result={'documents': [f'Documento de referencia para: {query}', 'Política corporativa simulada']},
            )
        if request.tool_name == 'case_lookup':
            return ToolResponse(
                tool_name=request.tool_name,
                ok=True,
                result={'case_id': request.payload.get('case_id', 'N/A'), 'status': 'simulado-en-analisis'},
            )
        if request.tool_name == 'publish_result':
            return ToolResponse(tool_name=request.tool_name, ok=True, result={'published': True})
        return ToolResponse(tool_name=request.tool_name, ok=False, result={}, error='Tool no implementada en mock')
