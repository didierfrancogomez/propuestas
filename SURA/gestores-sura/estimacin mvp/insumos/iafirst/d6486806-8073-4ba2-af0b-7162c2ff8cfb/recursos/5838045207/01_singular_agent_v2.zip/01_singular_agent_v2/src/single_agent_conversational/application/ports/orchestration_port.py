from typing import Protocol

from single_agent_conversational.domain.models import AgentRequest, AgentResponse


class OrchestrationPort(Protocol):
    async def run(self, request: AgentRequest) -> AgentResponse:
        ...
