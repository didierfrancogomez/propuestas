from pydantic import BaseModel, Field


class A2AAgentSkill(BaseModel):
    id: str
    name: str
    description: str
    tags: list[str] = Field(default_factory=list)


class A2AAuthentication(BaseModel):
    type: str
    scopes: list[str] = Field(default_factory=list)


class A2AAgentCard(BaseModel):
    name: str
    description: str
    version: str
    url: str
    skills: list[A2AAgentSkill]
    capabilities: dict = Field(default_factory=dict)
    authentication: A2AAuthentication
