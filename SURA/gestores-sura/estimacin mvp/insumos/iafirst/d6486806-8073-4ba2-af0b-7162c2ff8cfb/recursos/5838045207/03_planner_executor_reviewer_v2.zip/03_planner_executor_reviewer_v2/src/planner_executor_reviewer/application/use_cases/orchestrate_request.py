from planner_executor_reviewer.domain.models import AgentRequest, AgentResponse
from planner_executor_reviewer.application.ports.orchestration_port import OrchestrationPort
from planner_executor_reviewer.application.ports.telemetry_port import TelemetryPort


class OrchestrateRequestUseCase:
    def __init__(self, telemetry: TelemetryPort, orchestration: OrchestrationPort):
        self.telemetry = telemetry
        self.orchestration = orchestration

    async def execute(self, request: AgentRequest) -> AgentResponse:
        self.telemetry.event("agent.request.received", {"session_id": request.session_id})
        try:
            response = await self.orchestration.run(request)
        except Exception as exc:
            self.telemetry.error("agent.request.failed", exc, {"session_id": request.session_id})
            raise
        self.telemetry.event("agent.request.completed", {"session_id": request.session_id})
        return response
