from __future__ import annotations

from typing import Dict, Any
from .models import AgentRequest, AgentResponse, DecisionTrace, ToolRequest
from .memory import InMemoryMemoryStore
from .prompts import PromptRegistry
from .policy import PolicyEngine, PolicyViolation
from .llm_client import MockLLMGateway
from .mcp_client import MockMCPClient


class PlannerExecutorReviewer:
    """Patrón Planner-Executor-Reviewer.

    Separa quien planea, quien ejecuta y quien revisa antes de entregar o actuar.
    """
    def __init__(self, manifest, prompts_config):
        self.memory = InMemoryMemoryStore()
        self.prompts = PromptRegistry(prompts_config)
        self.policy = PolicyEngine(manifest)
        self.llm = MockLLMGateway()
        self.mcp = MockMCPClient()

    def plan(self, request: AgentRequest) -> Dict[str, Any]:
        needs_case = 'caso' in request.input_text.lower() or 'reclamacion' in request.input_text.lower() or 'reclamación' in request.input_text.lower()
        steps = [{'tool': 'knowledge_search', 'description': 'Buscar fuentes relevantes'}]
        if needs_case:
            steps.append({'tool': 'case_lookup', 'description': 'Consultar caso relacionado'})
        return {'objective': request.input_text, 'steps': steps, 'requires_human_approval': 'aprobar' in request.input_text.lower()}

    def execute(self, request: AgentRequest, plan: Dict[str, Any]) -> Dict[str, Any]:
        evidence = {}
        for step in plan['steps']:
            self.policy.validate_tool(step['tool'])
            response = self.mcp.call(ToolRequest(tool_name=step['tool'], payload={'query': request.input_text}, correlation_id=request.correlation_id, user_id=request.user_id))
            evidence[step['tool']] = response.result if response.ok else {'error': response.error}
        prompt = self.prompts.render('executor_response', objective=plan['objective'], evidence=str(evidence))
        draft = self.llm.complete(prompt, metadata={'intent': 'executor'})
        return {'draft': draft, 'evidence': evidence}

    def review(self, request: AgentRequest, plan: Dict[str, Any], execution: Dict[str, Any]) -> Dict[str, Any]:
        if plan.get('requires_human_approval'):
            return {'approved': False, 'reason': 'Requiere aprobación humana antes de ejecutar acción sensible', 'human_required': True}
        if not execution.get('evidence'):
            return {'approved': False, 'reason': 'No hay evidencia suficiente', 'human_required': False}
        return {'approved': True, 'reason': 'El resultado tiene evidencia y no requiere aprobación humana', 'human_required': False}

    def run(self, request: AgentRequest) -> AgentResponse:
        trace = []
        try:
            self.policy.validate_input(request.input_text)
            trace.append(DecisionTrace(step='planner.start', decision='create_plan', reason='Planner genera plan explícito'))
            plan = self.plan(request)
            trace.append(DecisionTrace(step='planner.finish', decision='plan_created', reason='Plan creado', metadata=plan))

            execution = self.execute(request, plan)
            trace.append(DecisionTrace(step='executor.finish', decision='tools_executed', reason='Executor ejecuta herramientas autorizadas', metadata=execution['evidence']))

            review = self.review(request, plan, execution)
            trace.append(DecisionTrace(step='reviewer.finish', decision='approved' if review['approved'] else 'rejected', reason=review['reason'], metadata=review))
            if not review['approved']:
                status = 'needs_human' if review.get('human_required') else 'rejected'
                return AgentResponse(correlation_id=request.correlation_id, answer='Resultado no aprobado automáticamente: ' + review['reason'], status=status, trace=trace, artifacts={'plan': plan, 'review': review})
            return AgentResponse(correlation_id=request.correlation_id, answer=execution['draft'], status='ok', trace=trace, artifacts={'plan': plan, 'review': review})
        except PolicyViolation as e:
            trace.append(DecisionTrace(step='policy.violation', decision='blocked', reason=str(e)))
            return AgentResponse(correlation_id=request.correlation_id, answer='Solicitud bloqueada por política.', status='blocked', trace=trace)
