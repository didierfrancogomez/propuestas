from __future__ import annotations

from typing import Any, Dict, List


class InMemoryMemoryStore:
    """Memoria mínima para referencia.

    En implementación real reemplazar por Cosmos DB, base documental,
    vector store o memoria corporativa aprobada por arquitectura.
    """
    def __init__(self):
        self.sessions: Dict[str, List[Dict[str, Any]]] = {}

    def append(self, session_id: str, item: Dict[str, Any]) -> None:
        self.sessions.setdefault(session_id, []).append(item)

    def get_recent(self, session_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        return self.sessions.get(session_id, [])[-limit:]

    def clear(self, session_id: str) -> None:
        self.sessions.pop(session_id, None)
