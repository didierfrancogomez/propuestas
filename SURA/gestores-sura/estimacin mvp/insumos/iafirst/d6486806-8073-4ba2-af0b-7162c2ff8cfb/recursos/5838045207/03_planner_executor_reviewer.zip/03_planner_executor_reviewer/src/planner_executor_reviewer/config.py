from __future__ import annotations

from pathlib import Path
from typing import Any, Dict
import yaml


def load_yaml(path: str | Path) -> Dict[str, Any]:
    with Path(path).open('r', encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    return data


def load_config(base_dir: str | Path) -> Dict[str, Any]:
    base = Path(base_dir)
    config: Dict[str, Any] = {}
    for name in ['agent_manifest.yaml', 'pattern.yaml', 'prompts.yaml', 'tools.yaml']:
        p = base / 'config' / name
        if p.exists():
            config[name.replace('.yaml', '')] = load_yaml(p)
    return config
