from pathlib import Path
from typer.testing import CliRunner

from agent_blueprint.cli import app
from agent_blueprint.generator.definition_builder import build_definition
from agent_blueprint.generator.renderer import ProjectRenderer


def test_create_orchestrator_worker(tmp_path: Path):
    runner = CliRunner()
    output = tmp_path / "agent"
    result = runner.invoke(app, [
        "create",
        "--name", "agent-test",
        "--profile", "orchestrator-worker",
        "--domain", "test-domain",
        "--owner", "test-team",
        "--output", str(output),
        "--non-interactive",
    ])
    assert result.exit_code == 0, result.output
    assert (output / ".agent-archetype.yaml").exists()
    readme = (output / "README.md").read_text(encoding="utf-8")
    env_example = (output / ".env.example").read_text(encoding="utf-8")
    assert "Arquitectura hexagonal" in readme
    assert "orchestrator-worker" in readme
    assert "Checklist para una version desplegable" in readme
    assert "AGENT_PROMPT_MANAGEMENT_URL" in env_example
    assert "AGENT_MCP_GATEWAY_URL" in env_example
    assert (output / "src" / "agent_test" / "adapters" / "outbound" / "langgraph" / "graphs" / "orchestrator_worker_graph.py").exists()
    assert not (output / "src" / "agent_test" / "orchestration").exists()
    container_py = (output / "src" / "agent_test" / "bootstrap" / "dependency_container.py").read_text(encoding="utf-8")
    graph_deps_py = (output / "src" / "agent_test" / "adapters" / "outbound" / "langgraph" / "dependencies.py").read_text(encoding="utf-8")
    app_py = (output / "src" / "agent_test" / "adapters" / "inbound" / "api_fastapi" / "app.py").read_text(encoding="utf-8")
    assert "AGENT_PROMPT_MANAGEMENT_URL is required" in container_py
    assert "GraphDependencies(" in container_py
    assert "Any | None" not in graph_deps_py
    assert "Depends(get_user_context)" in app_py
    assert "x_user_id" in app_py
    assert "app.state.container.orchestrate_request_use_case" not in app_py
    assert (output / "src" / "agent_test" / "adapters" / "outbound" / "prompt_management" / "adapter.py").exists()
    assert (output / "tests" / "fakes" / "fake_telemetry.py").exists()
    assert (output / "tests" / "test_orchestrate_use_case.py").exists()
    assert not (output / "prompts").exists()


def test_render_a2a_component(tmp_path: Path):
    output = tmp_path / "agent"
    definition = build_definition({
        "name": "agent-test",
        "profile": "orchestrator-worker",
        "domain": "test-domain",
        "owner": "test-team",
        "output": output,
        "features": {
            "a2a": True,
            "inbound": "http",
            "tools": "mcp",
            "memory": "session",
        },
    })

    ProjectRenderer().render(definition)

    assert (output / "config" / "a2a.yaml").exists()
    assert (output / "src" / "agent_test" / "adapters" / "inbound" / "a2a" / "routes.py").exists()
    assert (output / "src" / "agent_test" / "adapters" / "inbound" / "a2a" / "schemas.py").exists()
    assert not (output / "src" / "agent_test" / "adapters" / "protocols").exists()
    app_py = (output / "src" / "agent_test" / "adapters" / "inbound" / "api_fastapi" / "app.py").read_text(encoding="utf-8")
    routes_py = (output / "src" / "agent_test" / "adapters" / "inbound" / "a2a" / "routes.py").read_text(encoding="utf-8")
    schemas_py = (output / "src" / "agent_test" / "adapters" / "inbound" / "a2a" / "schemas.py").read_text(encoding="utf-8")
    assert "app.include_router(a2a_router)" in app_py
    assert "os.environ" not in routes_py
    assert "A2AAuthentication" in schemas_py
    assert "authentication: dict" not in schemas_py


def test_list_profiles():
    runner = CliRunner()
    result = runner.invoke(app, ["list-profiles"])
    assert result.exit_code == 0
    assert "orchestrator-worker" in result.output
