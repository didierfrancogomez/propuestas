from async_event_driven.domain.models import ToolSpec


class ToolNotFoundError(LookupError):
    def __init__(self, name: str, available_tools: list[str]):
        super().__init__(f"Tool '{name}' is not registered. Available tools: {available_tools}")
        self.name = name
        self.available_tools = available_tools


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, ToolSpec] = {}

    def register(self, tool: ToolSpec) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> ToolSpec:
        try:
            return self._tools[name]
        except KeyError as exc:
            raise ToolNotFoundError(name, sorted(self._tools)) from exc

    def list(self) -> list[ToolSpec]:
        return list(self._tools.values())
