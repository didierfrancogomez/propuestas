from typing import Protocol
from pydantic import BaseModel, Field
from orchestrator_worker.domain.models import TraceContext


class RenderedPrompt(BaseModel):
    prompt_id: str
    version: str
    content: str
    metadata: dict = Field(default_factory=dict)


class PromptPort(Protocol):
    async def get_prompt(
        self,
        prompt_id: str,
        version_policy: str,
        environment: str,
        variables: dict,
        trace_context: TraceContext,
    ) -> RenderedPrompt:
        ...
