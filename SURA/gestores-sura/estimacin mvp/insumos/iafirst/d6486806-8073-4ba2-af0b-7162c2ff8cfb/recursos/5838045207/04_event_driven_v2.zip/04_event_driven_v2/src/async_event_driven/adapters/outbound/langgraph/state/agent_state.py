from typing import Any, TypedDict


class AgentState(TypedDict, total=False):
    input: str
    session_id: str
    user_context: dict[str, Any]
    trace_context: dict[str, Any]
    plan: dict[str, Any]
    worker_tasks: list[dict[str, Any]]
    worker_results: list[dict[str, Any]]
    tool_calls: list[dict[str, Any]]
    final_response: str
    errors: list[str]
