from pathlib import Path
from typing import Any
from pydantic import BaseModel, Field


class Profile(BaseModel):
    name: str
    description: str = ""
    includes: list[str] = Field(default_factory=list)
    defaults: dict[str, Any] = Field(default_factory=dict)


class Capability(BaseModel):
    name: str
    description: str = ""
    components: list[str] = Field(default_factory=list)


class AgentDefinition(BaseModel):
    name: str
    package_name: str
    domain: str
    owner: str
    profile: str
    output: Path
    components: list[str]
    features: dict[str, Any] = Field(default_factory=dict)
    archetype_version: str = "0.1.0"
