import uvicorn

from orchestrator_worker.bootstrap.settings import Settings


def main() -> None:
    settings = Settings()
    uvicorn.run("orchestrator_worker.adapters.inbound.api_fastapi.app:app", host="0.0.0.0", port=settings.port, reload=False)


if __name__ == "__main__":
    main()
