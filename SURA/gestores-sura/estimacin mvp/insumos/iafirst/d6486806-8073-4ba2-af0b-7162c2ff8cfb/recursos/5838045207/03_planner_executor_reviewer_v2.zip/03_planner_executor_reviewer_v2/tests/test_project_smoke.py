def test_generated_project_imports():
    import planner_executor_reviewer
    assert planner_executor_reviewer.__version__ == "0.1.0"
