from typing import Protocol, Any


class TelemetryPort(Protocol):
    def event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        ...

    def error(self, name: str, error: Exception, attributes: dict[str, Any] | None = None) -> None:
        ...
