from pathlib import Path
from typing import Optional

from rich.console import Console

from agent_blueprint.generator.definition_builder import build_definition, load_definition_from_yaml
from agent_blueprint.generator.renderer import ProjectRenderer
from agent_blueprint.wizard.questions import run_wizard

console = Console()


def create_project(
    name: Optional[str],
    profile: Optional[str],
    domain: Optional[str],
    owner: Optional[str],
    output: Optional[Path],
    config_path: Optional[Path],
    non_interactive: bool,
) -> None:
    if config_path:
        definition = load_definition_from_yaml(config_path)
    elif non_interactive:
        if not name or not profile:
            raise ValueError("--name and --profile are required in non-interactive mode")
        definition = build_definition({
            "name": name,
            "profile": profile,
            "domain": domain or "default-domain",
            "owner": owner or "default-team",
            "output": output or Path(f"./{name}"),
            "features": {},
        })
    else:
        data = run_wizard()
        definition = build_definition(data)

    renderer = ProjectRenderer()
    renderer.render(definition)

    console.print("\n[bold green]Agent project generated successfully[/bold green]")
    console.print(f"Name: [bold]{definition.name}[/bold]")
    console.print(f"Profile: [bold]{definition.profile}[/bold]")
    console.print(f"Output: [bold]{definition.output}[/bold]")
    console.print("\nNext steps:")
    console.print(f"  cd {definition.output}")
    console.print("  make install")
    console.print("  make test")
    console.print("  make run")
