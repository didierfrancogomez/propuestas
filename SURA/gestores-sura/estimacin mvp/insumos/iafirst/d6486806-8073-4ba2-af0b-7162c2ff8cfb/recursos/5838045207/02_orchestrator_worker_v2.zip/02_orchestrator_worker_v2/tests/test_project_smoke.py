def test_generated_project_imports():
    import orchestrator_worker
    assert orchestrator_worker.__version__ == "0.1.0"
