from typing import Protocol
from planner_executor_reviewer.domain.models import PolicyDecision, UserContext, ToolSpec


class PolicyPort(Protocol):
    async def authorize_tool(self, user_context: UserContext, tool: ToolSpec) -> PolicyDecision:
        ...
