from dataclasses import dataclass

from planner_executor_reviewer.application.ports.llm_port import LLMPort
from planner_executor_reviewer.application.ports.policy_port import PolicyPort
from planner_executor_reviewer.application.ports.telemetry_port import TelemetryPort

from planner_executor_reviewer.application.prompts.prompt_runtime import PromptRuntime


from planner_executor_reviewer.application.ports.tool_port import ToolPort


from planner_executor_reviewer.application.ports.memory_port import MemoryPort




@dataclass(frozen=True)
class GraphDependencies:
    """Ports available to LangGraph node factories.

    Keep concrete adapters out of graph nodes. The dependency container builds this
    object once and passes it to build_graph().
    """

    telemetry: TelemetryPort
    policy_engine: PolicyPort
    llm: LLMPort | None = None

    prompt_runtime: PromptRuntime | None = None


    tools: ToolPort | None = None


    memory: MemoryPort | None = None


