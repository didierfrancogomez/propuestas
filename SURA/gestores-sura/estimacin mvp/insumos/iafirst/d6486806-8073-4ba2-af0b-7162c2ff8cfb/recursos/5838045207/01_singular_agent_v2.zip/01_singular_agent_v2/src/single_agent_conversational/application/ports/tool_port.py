from typing import Protocol
from pydantic import BaseModel, Field
from single_agent_conversational.domain.models import TraceContext, UserContext


class ToolExecutionRequest(BaseModel):
    tool_name: str
    arguments: dict
    user_context: UserContext
    trace_context: TraceContext


class ToolExecutionResult(BaseModel):
    tool_name: str
    success: bool
    result: dict | None = None
    error: str | None = None
    audit_metadata: dict = Field(default_factory=dict)


class ToolPort(Protocol):
    async def execute(self, request: ToolExecutionRequest) -> ToolExecutionResult:
        ...
