from async_event_driven.application.ports.orchestration_port import OrchestrationPort
from async_event_driven.domain.models import AgentRequest, AgentResponse


class FakeOrchestration(OrchestrationPort):
    async def run(self, request: AgentRequest) -> AgentResponse:
        return AgentResponse(
            answer=f"fake response for {request.input}",
            session_id=request.session_id,
            trace_context=request.trace_context,
        )
