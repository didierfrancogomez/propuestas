import shutil
import sys
from rich.console import Console
from rich.table import Table

console = Console()


def run_doctor() -> None:
    table = Table(title="agent-blueprint doctor")
    table.add_column("Check")
    table.add_column("Status")
    table.add_row("Python >= 3.11", "OK" if sys.version_info >= (3, 11) else "FAIL")
    table.add_row("docker", "OK" if shutil.which("docker") else "WARN")
    table.add_row("git", "OK" if shutil.which("git") else "WARN")
    table.add_row("make", "OK" if shutil.which("make") else "WARN")
    console.print(table)
