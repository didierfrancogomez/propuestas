from typing import Protocol

from orchestrator_worker.domain.models import AgentRequest, AgentResponse


class OrchestrationPort(Protocol):
    async def run(self, request: AgentRequest) -> AgentResponse:
        ...
