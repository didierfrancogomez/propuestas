# orchestrator-worker

Runtime de agente generado con el generador Agent Blueprint.

## Resumen del perfil

- Perfil: `orchestrator-worker`
- Dominio: `default-domain`
- Owner: `default-team`
- Paquete Python: `orchestrator_worker`
- Entrada principal: `python -m orchestrator_worker.main`

- Canal inbound: HTTP/FastAPI en puerto `8080`


- Herramientas: MCP Gateway gobernado por Policy Engine


- Memoria: adaptador episodico in-memory de referencia


## Patron de implementacion


Este proyecto usa el patron `orchestrator-worker`. Un orquestador central planifica la solicitud y despacha trabajo a workers especializados. Es util cuando el agente debe coordinar varios subprocesos, herramientas o agentes internos con consolidacion final.

Flujo principal:

1. El cliente invoca `POST /invoke`.
2. El nodo `plan_request` crea o ajusta el plan de trabajo.
3. El nodo `dispatch_worker_tasks` prepara la ejecucion de workers.
4. El nodo `finalize_response` consolida resultados en `final_response`.
5. El caso de uso entrega `AgentResponse` con plan y resultados de workers en `metadata`.


## Arquitectura hexagonal

El proyecto sigue Ports and Adapters. La regla central es que el dominio no conoce infraestructura. Las dependencias apuntan hacia adentro:

```text
adapters -> application -> domain
bootstrap -> adapters + application + domain
```

### Capas

| Capa | Responsabilidad | Puede depender de |
|---|---|---|
| `domain/` | Modelos puros del negocio y contratos de datos: `AgentRequest`, `AgentResponse`, `TraceContext`, `ToolSpec`, `PolicyDecision`. | Librerias de modelado como Pydantic. No debe importar adapters, FastAPI, httpx ni settings. |
| `application/ports/` | Puertos que expresan lo que la aplicacion necesita: LLM, prompt management, telemetry, policy, tools, memoria, eventos o agentes remotos. | `domain/` y tipos estandar. |
| `application/use_cases/` | Casos de uso de entrada. `OrchestrateRequestUseCase` recibe puertos por constructor y no instancia adaptadores concretos. | `domain/` y `application/ports/`. |
| `application/prompts/` | Runtime para resolver prompts versionados desde Prompt Management. | `PromptPort` y `TraceContext`. |
| `adapters/inbound/` | Entradas externas como FastAPI, A2A o listeners de eventos. Transforman protocolos externos en modelos de dominio. | `application/` y `domain/`. |
| `adapters/outbound/` | Implementaciones concretas de puertos: LLM Gateway, MCP Gateway, Prompt Management, Policy Engine, Telemetry, Event Broker y LangGraph. | `application/ports/`, `domain/` y clientes de infraestructura. |
| `adapters/outbound/langgraph/` | Adaptador que implementa `OrchestrationPort`. Contiene runner, dependencias, estado, grafos y factories de nodos. | `application/ports/`, `domain/` y LangGraph. |
| `bootstrap/` | Composition root. Crea settings, adaptadores, grafo y casos de uso una sola vez al iniciar. | Todas las capas. |
| `config/` | Configuracion declarativa del agente, runtime, prompts, A2A y capacidades. | No aplica. |
| `tests/` | Tests unitarios, contract tests y fakes. | Puede usar fakes de puertos sin tocar infraestructura real. |

### Reglas obligatorias

- No instanciar adaptadores dentro de casos de uso o nodos.
- No importar `adapters/` desde `domain/` ni desde `application/ports/`.
- Toda llamada externa debe pasar por un puerto.
- Toda tool debe tener contrato, autorizacion por `PolicyPort` y trazabilidad.
- Todo evento de telemetria debe incluir al menos `correlation_id` cuando aplique.
- Prompt Management es obligatorio; los prompts productivos no se guardan en este repositorio.

## Estructura generada

```text
.
|-- config/
|   |-- agent.yaml
|   |-- runtime.yaml
|   |-- prompt-management.yaml
|   |-- a2a.yaml
|-- src/orchestrator_worker/
|   |-- domain/
|   |-- application/
|   |   |-- ports/
|   |   |-- use_cases/
|   |   |-- prompts/
|   |-- adapters/
|   |   |-- inbound/
|   |   |-- outbound/
|   |   |   |-- langgraph/
|   |   |   |   |-- graphs/
|   |   |   |   |-- nodes/
|   |   |   |   |-- state/
|   |-- bootstrap/
|   |-- main.py
|-- tests/
|-- Dockerfile
|-- Makefile
|-- pyproject.toml
```

## Configuracion

La clase `Settings` lee variables con prefijo `AGENT_`. Copie `.env.example` a `.env` para ejecucion local o defina las mismas variables en su plataforma de despliegue.

| Variable | Requerida | Uso |
|---|---|---|
| `AGENT_PORT` | No | Puerto en el que corre el servicio. Por defecto `8080`. Cambiar en `.env` para correr multiples servicios en la misma maquina. |
| `AGENT_AGENT_NAME` | No | Nombre visible del agente. Por defecto `orchestrator-worker`. |
| `AGENT_ENVIRONMENT` | Si | Ambiente usado por settings y Prompt Management: `local`, `dev`, `qa`, `staging` o `production`. |
| `AGENT_PROMPT_MANAGEMENT_URL` | Si | Servicio externo para resolver prompts versionados. Se valida en startup. |
| `AGENT_LLM_GATEWAY_URL` | Si | Endpoint compatible con el gateway LLM corporativo. Se valida en startup. |
| `AGENT_MCP_GATEWAY_URL` | Si | Endpoint del MCP Gateway para ejecutar tools. |
| `AGENT_PUBLIC_AGENT_URL` | Si para A2A | URL publica usada en el Agent Card. |


### Configuracion del agente

`config/agent.yaml` identifica el agente:

```yaml
agent:
  id: "orchestrator-worker"
  name: "orchestrator-worker"
  domain: "default-domain"
  owner: "default-team"
  profile: "orchestrator-worker"
```

### Prompt Management

`config/prompt-management.yaml` declara los prompts que el agente espera resolver. Para dejar el agente desplegable:

1. Cree los prompts reales en la plataforma de Prompt Management.
2. Mantenga en este repositorio solo ids, variables y metadatos no sensibles.
3. Configure `AGENT_PROMPT_MANAGEMENT_URL`.
4. Use `AGENT_ENVIRONMENT` para apuntar a versiones del ambiente correcto.

### LLM Gateway

Configure `AGENT_LLM_GATEWAY_URL` con el endpoint del gateway corporativo. Los nodos no deben llamar directamente a `httpx`; deben usar `LLMPort`.

### Telemetria

`OpenTelemetryAdapter` usa `opentelemetry.trace.get_current_span()` para emitir eventos y errores sobre el span activo. Para produccion:

1. Configure un `TracerProvider` al iniciar la aplicacion.
2. Agregue el exporter corporativo OTLP/collector.
3. Propague `trace_id`, `span_id` y `correlation_id` desde entradas inbound hacia puertos outbound.
4. Evite `print` para observabilidad productiva; use spans, eventos y logs estructurados.


### MCP Tools

Configure `AGENT_MCP_GATEWAY_URL`. Toda tool debe:

1. Estar declarada con `ToolSpec`.
2. Definir `input_schema`, `output_schema`, scopes y nivel de riesgo.
3. Pasar autorizacion por `PolicyPort`.
4. Ejecutarse por `ToolPort`.
5. Registrar `trace_context` y auditoria.



### A2A

Configure `AGENT_PUBLIC_AGENT_URL` con la URL publica del servicio. Actualice `adapters/inbound/a2a/routes.py` para publicar skills reales, scopes requeridos y capacidades soportadas.




## Ejecucion local

### Paso 1 — Crear el entorno virtual

```powershell
python -m venv .venv
```

### Paso 2 — Activar el entorno virtual

```powershell
# Windows
.venv\Scripts\activate

# Mac / Linux
source .venv/bin/activate
```

### Paso 3 — Instalar dependencias

```powershell
pip install -e ".[dev]"
```

> Este proyecto usa `pyproject.toml` en lugar de `requirements.txt` (estandar moderno de Python).
> El comando `pip install -e ".[dev]"` es equivalente al antiguo `pip install -r requirements.txt`.

### Paso 4 — Crear el archivo `.env`

Crea un archivo `.env` en la raiz del proyecto con el siguiente contenido minimo para ejecucion local:

```env
AGENT_PORT=8080
AGENT_LLM_GATEWAY_URL=http://localhost:9000
AGENT_MCP_GATEWAY_URL=http://localhost:8082
AGENT_PROMPT_MANAGEMENT_URL=http://localhost:9001
AGENT_ENVIRONMENT=local
```

> `AGENT_PORT` define el puerto en el que corre el servicio. Cambialo en el `.env` si necesitas correr
> varios servicios en la misma maquina sin modificar el codigo:
> - Orquestador: `AGENT_PORT=8080`
> - Agente especializado: `AGENT_PORT=8081`
> - MCP Server: `AGENT_PORT=8082`

> En ambientes superiores (dev, qa, produccion) estas URLs apuntan a los servicios reales del Control Plane de SURA.


### Paso 5 — Levantar el servicio

```powershell
python -m orchestrator_worker.main
```

O con el Makefile:

```powershell
make run
```


El servicio queda disponible en `http://localhost:8080`.

> Si levantas multiples servicios en la misma maquina, cada uno debe usar un puerto diferente.
> Cambia el puerto en `src/orchestrator_worker/main.py` antes de levantar.

### Verificar que esta corriendo

```powershell
curl http://localhost:8080/health
```

Respuesta esperada:
```json
{"status": "ok", "agent": "orchestrator-worker"}
```

### Endpoints disponibles

| Metodo | Path | Uso |
|---|---|---|
| `GET` | `/health` | Liveness check. |
| `POST` | `/invoke` | Ejecuta el agente. |
| `GET` | `/.well-known/agent-card.json` | Agent Card A2A. |


### Ejemplo de invocacion

```powershell
curl -X POST http://localhost:8080/invoke `
  -H "Content-Type: application/json" `
  -H "x-correlation-id: demo-001" `
  -d '{"input":"Hola","session_id":"s-001"}'
```


## Despliegue

### Imagen Docker

```bash
docker build -t orchestrator-worker:0.1.0 .
docker run --rm -p 8080:8080 --env-file .env orchestrator-worker:0.1.0
```

### Checklist para una version desplegable

- Configurar variables de entorno en la plataforma de despliegue.
- Crear prompts reales en Prompt Management.
- Conectar `LLMPort` con el LLM Gateway real.
- Registrar tools reales en MCP Gateway y definir scopes.
- Validar policy hooks para cada tool.
- Reemplazar `InMemoryMemoryAdapter` por una memoria persistente si se requiere continuidad entre replicas.
- Completar nodos del grafo usando factories que reciban `GraphDependencies`.
- Activar OpenTelemetry con el backend corporativo.
- Ejecutar tests unitarios, contract tests de puertos y smoke tests.
- Ejecutar `agent-blueprint validate --path .`.

## Como extender el agente

1. Agregue modelos especificos del dominio en `domain/`.
2. Defina nuevos puertos en `application/ports/` si necesita capacidades externas.
3. Implemente adaptadores concretos en `adapters/outbound/`.
4. Cablee adaptadores en `bootstrap/dependency_container.py`.
5. Modifique nodos y grafo en `adapters/outbound/langgraph/`.
6. Cubra la logica con fakes de puertos en tests.

## Validacion del arquetipo

```bash
agent-blueprint validate --path .
```

El objetivo de esta validacion es confirmar que el proyecto conserva las reglas del template: Prompt Management obligatorio, tools gobernadas por policy, estructura hexagonal y componentes requeridos por perfil.
